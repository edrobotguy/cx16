Commander X-16 Assembly Language Editor 
v1.1.37.0077 
by Ed Minchau, spider_boris@yahoo.com
2020

-----------------------------------


0) Introduction

The CX16 Assembly Language Editor was made to allow easy development of assembly language programs on the Commander X16.
The editor is meant to be as small as possible, while still having lots of functionality.  Users can write their code
directly in the CX16 environment, test it from within the editor, and easily save their code to disk.  Addresses can be
replaced with labels, and code can be commented.

The editor is mostly located in paged RAM from $A000 to $BFFE.  There is a short bootstrap program located from $0400 to
$080F.  The bootstrap program loads and runs the main editor program, but it also contains lots of 16 bit subroutines and
several short subroutines that end users might find useful in their own programs.  The metadata file DEFAULT.LBL is 
currently located at $8000 to $9EFF, but that will change in the next version.  The next version will include a program
which converts your current metadata files into the future format. 

This leaves the RAM from $0810 to $7FFF available for the user's own assembly language program, almost 30 kilobytes of
contiguous space.  (The next version of the editor will free up the space from 8000-9EFF, allowing you almost 37.75kB of
space for your programs in low RAM, and might also allow you to program in paged RAM as well.)

The editor sets the screen to 40x30 character display mode, because my eyes are getting old and I need new glasses.


-----------------------------------


1) Contents

	0. Introduction
	1. Contents
	2. Version and License
	3. Revision History
	4. Getting Started
		4.1 Demo video
	5. Display Modes
		5.0 Status bar
		5.1 Assembly code, branch to address
		5.2 Assembly code, branch relative
		5.3 Data mode, block byte
		5.4 Data mode, single byte
		5.5 Character mode
	6. Function and Arrow Keys
	7. Assembly Language Notation
		7.1 Four Character Codes
		7.2 Parameters
			7.2.1 Referencing the Low Byte, High Byte, or String Length of a Label
			7.2.2 Referencing Zero page addresses by Label
	8. Editor Functions
		8.1 GOTO, EXEC, SAVE, QUIT
		8.2 COMM, DCOM, SLBL, DLBL
		8.3 CHAR, DATA
		8.4 COPY, MOVE, INSErt, DELEte
		8.5 WORD, DWRD, BYTE, DBYT, STRIng, DSTR
		8.6 LLBL
		8.7 Branch-to-address pseudocommands
	9. Labels
		9.1 setting and deleting labels
		9.2 default labels
			9.2.1 Commodore Kernal labels
			9.2.2 Commander X-16 API labels
			9.2.3 VERA labels
			9.2.4 Zero Page labels
			9.2.5 16 bit subroutine labels
			9.2.6 Other Default Labels
		9.3 FSTR and FEND
	10. Comments
	11. 16 bit subroutines
	12. Future work

	Appendix A: table of 65c02 commands sorted by opcode
	Appendix B: alphabetical list of 65c02 commands  
	Appendix C: alphabetical list of 16 bit subroutines

-----------------------------------


2) Version and License

Major version: 1
Minor version: 1
emulator version: 37
build number: 0077

IMPORTANT: this is *only for version 37* of the emulator.  There is no guarantee it will work for other emulator
versions.

The license of this software is pretty straightforward: use any of it that you like in your own software, just leave
the following 80 byte string (currently stored at $0691-$06DF) somewhere in the code:

YOU CAN USE ANY OF THIS CODE,JUST LEAVE
THIS MESSAGE SOMEWHERE ED MINCHAU 2019

Since the license is stored in memory within EDIT.PRG, which will itself become part of user programs, you
don't actually need to do anything.


-----------------------------------


3) Revision History

	v1.1.37.0077: update for emulator version 37

		- changed default device number to 8
		- refactored, discovered to my astonishment that I had inadvertently written an object oriented 
			program.  Just worked out that way as a result of writing the code as compactly as possible.
		- optimized code as much as possible, except where that would detract too much from readability.
		- moved LBL file from paged RAM to $8000-$9EFF - this will change in future versions, and an updating
			program will be included in the future to update from this format to the future format
		- moved bootstrap program to $0400-$080F, renamed EDIT.PRG
		- separated default labels from user's labels, default labels are stored in MLEDIt.BIN rather than 
			LBL file; there is now space allocated for 253 user labels, plus FSTR and FEND
		- simplified SAVE for the user
		- added labels for the full CX16 kernel and all VERA registers
		- added labels to the zero page locations suggested by the devs as 16 bit registers
		- added 16 bit operations in EDIT.PRG, which affect flags the same way as their 8 bit analogues
		- added functions WORD/DWRD, BYTE/DBYT, STRIng/DSTR, INSErt, DELEte, LLBL
		- changed display/entry of zero page instruction parameters to allow reference by label
		- changed display/entry of immediate mode parameters to allow reference to low or high byte of user 
			label or length of string associated with user label
		- added branch-to-absolute-address pseudocommands for BBR0..BBR7, BBS0..BBS7
		- changed display of address field so that it is printed in reverse character mode if the address 
			corresponds to a label
		- changed MOVE to change parameters of any 3-byte command located between addresses FSTR and FEND
			that references a label which is being moved so that they all point to the new label address
			(INSErt and DELEte share this code, and also look for those branch commands between -128 to
			+127 bytes of the current address which need to change and changes them appropriately.)


	v1.0.34.0038: first release

-----------------------------------


4) Getting Started

If you're reading this README file, then you've already downloaded the code from GitHub.  Good.  Just make sure you've
extracted everything from the zip file (EDIT.PRG, DEFAULT.LBL, MLEDIT.BIN, and editorREADME.TXT) into your
directory containing the emulator version 37.  To start, launch the emulator, and then type:

LOAD"EDIT.PRG",8,1
RUN

You will be shown the version information, the license, a status bar and PRESS ANY KEY TO CONTINUE.  Click a key and
the editor starts in mode 1 at address $0810, the first available address for user programs.


4.1) Demo Video

A demonstration video, showing a quick overview of the editor and its functions is avalable on YouTube at

https://youtu.be/uZLBTg8KP_E


-----------------------------------


5) Display Modes

There are five display modes available in the editor.  Use the F4 key to cycle between the display modes.

To keep the parsing code short, the keypresses that are accepted by the editor are limited.  When entering a command, only
letters, numbers, and the symbols + - # and / are allowed.  When entering two hex digits, only the keys 0 to 9 and A to F
are accepted.  When moving the cursor in mode 1, 2, 4, or 5, only up or down arrow keys, F4, and letters are allowed.  When 
moving the cursor in mode 3, only f4, the four arrow keys, or a hexadecimal digit are allowed.  When entering a filename, 
only letters, numbers, a slash, a period, or a Return are allowed.  For comments, only letters, numbers, spaces, Return, and
the symbols + - # / < and > are allowed.

In all cases, whether entering commands or parameters or other data, backspace is allowed, to a point.  If you backspace to
the beginning, then whatever you were entering aborts and goes back to the editing mode, as if nothing ever happened and let
us never speak of this thing again.  For instance, if you start entering a command and change your mind halfway through entering
a parameter, backspacing to the beginning of that parameter just aborts the command entry, the command isn't stored at that
location, and the display reverts to as it was before you started typing the command.  If you enter a four character code that
isn't a 65c02 command or an editor function, again the display reverts to as it was before you started typing the erroneous
code.  Syntax errors are just not allowed at all.


5.0) mode 0: Status bar

Mode 0 isn't really an editing mode.  It simply displays a truncated status bar (no program counter), and 

PRESS ANY KEY TO CONTINUE

As soon as a key is pressed, it clears the screen and switches to mode 1.  This mode is called on startup and any time you
EXECute code.  Peri Fractic, can I get a keyboard with one of the X16 keys replaced with a key marked ANY, please?  Then I
could say, there it is.


5.1) mode 1: Assembly code, branch to address

The first mode shows the assembly language code in the notation (see section 7) unique to this editor.  This mode also
shows all branches as being to an absolute address rather than to a relative address.  The branch commands themselves are 
displayed differently in this mode e.g. BNEA instead of BNE# (see section 8.4).  In either mode 1 or mode 2 you can enter
branches as either to an absolute address or a relative address (though they are all stored as relative addresses), but
in this mode all branches are displayed with absolute addresses.

Each line on this screen corresponds to one command.  It shows the address, the command, any parameters, the list of 1-3
bytes representing that line of code, and any comments.  If the address at the top of the screen happens to be a parameter
rather than a command, the editor will still try to display it as a command.  As a result the top few lines of the screen 
may be muddled.  Moving the cursor up to the top of the screen, and then up one or two more times, will eventually bring
an actual command to the top of the screen.

When pressing F4 to switch to mode 2, the cursor does not change position and the address at the top of the screen remains
the same.


5.2) mode 2: Assembly code, branch relative

The second mode differs from the first mode in the way it displays branches, always showing branches to relative
addresses.  You can still enter branches to absolute addresses in this mode, but they will immediately be displayed as
the correct relative addresses.

Also, if a command is a zero page command such as LDA0 and the parameter corresponds to an address with a label, then the
label will be displayed instead of the parameter (its value is still displayed in the byte list to the right).  So, in mode 1
a command would be displayed LDA0 02 but in mode 2 the same command is LDA0 R0/L (see section 9.2.4).

In either mode 1 or mode 2 you can enter such zero page parameters as labels instead by clicking the slash key followed by the
label.  If the label you choose isn't on zero page the editor will point a finger and laugh at you and just abort out of the
command entry, the command won't be stored in memory, and the display will revert to as it was before you started typing the
command.

This includes the BBR and BBS commands as well; even though they haven't been fully implemented on the emulator last time I
checked, they will be available on the 65C02 chip on the actual Commander X16.  In mode 1 a command might be displayed as
BR7A 03,LOOP and in mode 2 that same command would be displayed something like BBR7 R0/H,F3.  You could enter that command in
either mode 1 or 2 as BR7A/R0/H,LOOP or BBR7 03,F3 and the display would immediately change to BR7A 03,LOOP in mode 1 or 
BBR7 R0/H,F3 in mode 2. (see section 8.7)

When pressing F4 to switch to mode 3, the address currently pointed to by the cursor becomes the address at the top left
corner of the screen, and the cursor moves to that location.


5.3) mode 3: Data mode, block byte

This third mode shows 30 rows of 8 bytes per row, with each of the 8 bytes first displayed as hex digits, and then displayed
as 8 characters.  If a byte is not a printable character then it is displayed as a default checkerboard character.

The address at the left side of the screen is the address of the first of the eight bytes on that row. Data can be entered
wherever the * cursor is, as hex digits.  In this mode, you can use the left and right arrows as well as the up and down arrows
to move the cursor around.  The editor will only allow you to enter hex digits, cursor moves, or F4.

When switching to mode 4 by pressing F4, the address currently pointed to by the cursor becomes the address at the top of
the screen, and the cursor moves to the top.


5.4) mode 4: Data mode, single byte

The fourth mode shows one byte per row, first as two hex digits and then the individual bits, with a period representing a zero
and a filled circle representing a one.  Any comment attached to that address is also shown.  Data can be entered as hex digits
wherever the * cursor is, or you can move the cursor up or down.  Other than that, F4 is the only other key the editor will
recognize.

When switching to mode 5 by pressing F4, the address at the top of the screen remains the same and the cursor points to the same
address as in mode 4.


5.5) mode 5: Character mode

The fifth display mode shows one byte per row again, this time represented as characters.  The hex digits of the byte are also
shown, and any comment attached to that address.  In this mode, characters can be entered wherever the * cursor is.  Certain keys
will not be entered as characters in this mode: the up and down arrow keys just move the cursor up and down, and F4 will switch
the editor back to mode 1.  However, all other keys on the keyboard can be entered as characters this way.  It is pronounced
Fronk-en-STEEN.

If a byte is not a printable character, then it is shown as a default checkerboard character.

When switching back to mode 1 by pressing F4, the address currently pointed to by the cursor becomes the address at the top of
the screen, and the cursor moves to the top.


-----------------------------------


6) Function and arrow keys

In all editor modes, F4 switches to the next display mode, and the up and down arrow keys move the cursor.  The left and right
arrow keys only work in mode 3.


-----------------------------------


7) assembly language notation

7.1) Four Character Command Codes

In an effort to keep the editor as small as possible, I had to make certain tradeoffs.  The most important tradeoff was changing
the notation of the assembly language code from a standard notation to one where each command is represented by a unique four-
character code.  For most commands, the first three characters are identical to the standard notation, and the fourth character
represents the addressing mode.  It might raise the hackles of experienced 6502 programmers, but it doesn't take long to get used
to the notation, and once you're used to it it's actually easier to read than the standard notation; one's eyes move straight down
the screen instead of bouncing left and right.

Let's take LDA as an example.  This command loads the accumulator.  There are nine different LDA commands, and in standard 65c02
editors a parser would have to figure out which of the nine LDA commands was desired by looking at the syntax of the parameters
which followed.  In this editor however, each of the nine LDA commands has a unique fourth character indicating addressing mode, 
eliminating much of the code needed to parse user input.  By entering the unique four character code, the editor knows exactly
what type of parameters to expect and will only allow those type of parameters.  For instance, LDAA expects a parameter four
characters long, either an address or a label.  It won't take just two or three characters.  Five is RIGHT OUT.

Addressing mode		4-character code	standard notation
immediate		LDA#			LDA #
zero page		LDA0			LDA zp
zero page,X		LDAZ			LDA zp,X
absolute		LDAA			LDA addr
absolute,X		LDAX			LDA addr,X
absolute,Y		LDAY			LDA addr,Y
(indirect,X)		LDA+			LDA (zp,X)
(indirect),Y		LDA-			LDA (zp),Y
(indirect)		LDA/			LDA (zp)


There are a couple of commands (LDX and STX) that have a zero page,Y addressing mode.  These are represented by the four-
character codes LDXZ and STXZ.

There is also an implied addressing mode (e.g. INXI, TAYI, PHYI, RTSI).  There are a few of the Implied mode commands
represented with other characters than I as the fourth character, mostly having to do with flags or clarity:
e.g. CLCF, SECF, CLID, SEID, CLDM, SEDM, NOPE, BRK0, WAIT, STOP

The new 65c02 commands RMB0 through RMB7 and SMB0 through SMB7 are the same as the standard notation, since they are already
unique four-character codes.

The branching commands are all in a relative addressing mode.  For BBR0 through BBR7 and BBS0 through BBS7, the commands are
identical to standard 65c02 notation, since they're already unique four-character codes.  The other branch operations use the 
symbol # to represent relative addressing mode, with one exception: the new 65c02 unconditional branch command has the code BRAN.

Relative branches are easy for the computer to understand, but a little harder for programmers.  The editor has the ability to
input branches to an absolute address, which it then converts for you to a relative address.  These pseudo-commands are:
BPLA, BMIA, BVCA, BVSA, BRAA (the new unconditional branch, but to an address), BCCA, BCSA, BNEA, and BEQA. There are equivalent
commands for the BBR and BBS commands as well. (see section 8.4)

A few commands - ASL, LSR, ROL, ROR, DEC, and INC - have both an absolute addressing mode and an Accumulator mode.  They can't
both use the letter A as the fourth character.  For these six commands the Accumulator mode is treated as Implied mode.


command 	Addressing mode		standard notation	4-character code
					
ASL     	Accumulator		ASL A   		ASLI
ASL     	absolute		ASL addr		ASLA
LSR     	Accumulator		LSR A   		LSRI
LSR     	absolute		LSR addr		LSRA
ROL     	Accumulator		ROL A   		ROLI
ROL     	absolute		ROL addr		ROLA
ROR     	Accumulator		ROR A   		RORI
ROR     	absolute		ROR addr		RORA
DEC     	Accumulator		DEC A   		DECI
DEC     	absolute		DEC addr		DECA
INC     	Accumulator		INC A   		INCI
INC     	absolute		INC addr		INCA


The 6502 had a number of unused / undocumented opcodes, some of which actually did something useful and some which wreaked
havoc.  This has been changed for the 65c02, where all unused opcodes are one, two, or three byte NOP commands.  These are
represented in the editor by the codes NOP1, NOP2, and NOP3, respectively.

The full list of commands is given in both Appendices A and B.  Appendix A lists the commands in order of opcode, with the
4-character codes assigned to each command, the standard notation, number of bytes, and number of cycles.  Appendix B lists
the commands in alphabetical order, including the addressing mode, opcode, 4-character code, standard notation, number of 
bytes, number of cycles, and the flags affected by each command. 


7.2) Entering Parameters

Once you enter a four character command, if it is a two or three byte command then you need to enter the parameters.  For
three byte commands (other than BBR0..7 and BBS0..7) the parameter entered can be either an absolute address or a label (see
section 9).  For the BBR and BBS commands, the parameters are a zero page address and a relative branch address (see section
8.7).

For two byte commands, the editor expects the parameter to be two hex digits, for the most part.  However, there are exceptions
to this to make the programmer's life easier, detailed next.


7.2.1) Referencing the Low Byte, High Byte, or String Length of a Label

For immediate mode commands such as LDA#, you can refer to an attribute of a label: either the length of a string associated
with that label, the low byte of the label, or the high byte of the label.  For instance, if a string has been associated with
a label (see section 8.5) then we can load the accumulator with the length of the string like this:

LDA#L and then the label name.

Or, to load X with the low byte of a label:

LDX#< and then the label name.

Similarly, to Exclusive-Or with the high byte of a label:

EOR#> and then the label name.

When you view your code in mode 2, these immediate mode parameters are displayed as hex digits, but in mode 1 they are displayed
with the L or < or > in reverse character mode, and then the associated label is displayed.


7.2.2) Referencing Zero page addresses by Label

For zero page commands like LDA0 or STA0, if the zero page address is associated with a label, then you can refer to the label
instead of entering the address as hex digits:

LDA0/ and then the label name

This works for both the default zero page labels and for any user labels in zero page.  It also works on the zero page parameter
of the BBR and BBS commands.

In mode 2, the zero page parameters are displayed as labels if a label is associated with that zero page address, and in mode 1
the zero page parameters are displayed as two hex digits.


-----------------------------------


8) Editor Functions

Besides 65c02 commands, there are 22 editor functions and 25 pseudocommands recognized by the editor.

These functions and pseudocommands only work in modes 1 and 2.


8.1) GOTO, EXEC, SAVE, QUIT

These are the four most important functions in the editor.


8.1.1) GOTO

GOTO allows you to go to any address.  Just type GOTO and the address or label.  The address will then be moved to the top of
the screen and the cursor will point at that address.


8.1.2) EXEC

EXEC turns over control of the computer from the editor to the code located at the address entered.  Just type EXEC and the
address or label of the address to be executed.  If your code ends in an RTSI command, then when your code is finished control
will return to the editor in mode 0, displaying the status bar before returning you to mode 1.  This is very useful for testing
sections of code or even an entire program.

If the program you're EXECuting crashes, just Ctrl-R to do a soft reset, and type SYS1024 to bring back the editor and the labels
you most recently saved.  The Ctrl-R will set the starting link in the BASIC program to 0000, so you have to change $0801 to $0B
and $0802 to $08 in order to correct that (I'll make this automatic in the next version).  It's a good idea to save before
testing with EXEC.


8.1.3) SAVE

SAVE lets you save your work.  To save a file in assembly language, you need to specify logical file number, device number, and
secondary address; for now, this is set to the main directory of the X-16 emulator.  Then you need to set the file name, the start
address of the file, and the location of the last byte in the file plus one.

The SAVE function tries to set the start and end+1 addresses by looking for the special labels FSTR and FEND (see section 9.4); if
one of those labels is not set, an error message is shown.  If they are both present, the function then prompts for a filename, 
up to 32 characters long.  The only characters allowed are letters, numbers, the period, the slash, and Return.

Once the FSTR, FEND, and filename are set, the function prompts ARE YOU SURE?(Y/N) and waits for either a Y or N to be pressed.  

If Y, the function creates another filename by searching backwards in the user's filename for the last period, placing the file
extension LBL afterwards.  If the filename is so long that the last period is the 29th or later character, then the label
filename is the first 28 characters of the user's filename followed by .LBL ; if there is no period in the user's filename, then
.LBL is appended to the user's filename at the end or at the 29th character, whichever is less.

This label filename is used to create a companion label file to the user's program.  That way each of the user's programs has a
unique label file, which is loaded whenever the user's program is loaded for editing.  This file contains all of the labels,
comments, and other metadata.

Then the function saves both the user's program and the corresponding label file.

It's important to note that the EDIT.PRG file starts at $0400, and that is also the default value of FSTR.  The only BASIC
command in this file is

1 SYS 2061

which corresponds to location $080D.  The command stored at $080D is JMPA FSTR, which loads and runs the editor, but when you want
your program to run upon loading rather than the editor, just change these three bytes to a JMPA to the start of your program.  If
you want to get back into the editor after having done that and saved your program, just load your program and type

SYS 1024

This will go into the routine that loads and launches the editor and loads the labels and comments for the user's program.  This
is also useful if your programs crashes while testing; just Ctrl-R to do a soft reset, and SYS1024 to load the editor and the
labels stored in your last SAVE.  If this happens, make sure that $0801 contains $0B, and $0802 contains $08, as the soft reset
sets them both to zero.


8.1.4) QUIT

QUIT takes no parameters.  It triggers an ARE YOU SURE?(Y/N) prompt, which waits for Y or N to be pressed.  If Y, the screen 
returns to the normal 80 column mode and is cleared and control is returned to BASIC.  If N, it returns back to mode 1 or 2.


8.2) COMM, DCOM, SLBL, DLBL

These four commands set and delete comments and labels, respectively.  Comments are covered in more detail in section 10 below,
and labels are covered in section 9.


8.3) CHAR, DATA

These two are the "convenience" functions.  Having them around just makes life easier.

When editing in mode 1 or mode 2, sometimes you will want to enter either raw data or to enter data as characters.  You can hit
F4 a few times to switch to mode 4 or mode 5, or you can go straight to mode 4 by typing

DATA

or straight to mode 5 by typing 

CHAR

It might seem like these are redundant commands, particularly since it could be fewer keypresses to just use F4 a few times, but
they actually come in quite handy for a psychological reason: your train of thought isn't interrupted by counting keypresses.  In
either case, the address pointed to by the cursor in mode 1 or 2 becomes the address at the top of the screen, and the cursor
moves to the top.


8.4.1) COPY and MOVE

The COPY and MOVE functions are closely related.  For each of these commands, there are three prompts: FROM, TO, and #BYTES.
Unsurprisingly, these are the source address, destination address, and number of bytes to be moved or copied.  Enter a number from
01 to FF for #BYTES; entering 00 aborts the copy or move.

In both cases, if the data is being copied or moved from a lower address to a higher address, it starts at the last byte and works
its way to the first, and if going from higher address to lower address it does so from first to last.  This avoids the possibility
of accidentally overwriting data before it can be copied or moved.

In both cases if there is a label or comment at an address in the destination group of bytes, that label or comment is deleted; if
on the other hand a user label is attempted to be moved onto an existing default label, the user label gets deleted.

The difference between COPY and MOVE is that COPY does not affect the source data.  For MOVE, if a label or comment is encountered
in the source data, that label or comment is also moved to the destination (unless the label is being moved onto a default label).
And once data is moved to the destination, the source byte is replaced by a NOPE.

Note that when you MOVE a byte from an address associated with a label, the label itself moves and any code between $080D and FEND
that references that label also changes.  Any 3 byte command (other than the BBR and BBS commands) that has that label as its
parameter changes to point to the new location.


8.4.2) INSErt and DELEte

INSE and DELE are closely related to the MOVE command, except instead of moving a small number of bytes these commands shift your
entire program by the number of bytes entered, starting wherever the cursor happens to be.  When INSErting or DELEting bytes within
a string, the string length value changes and any command referencing that string length changes to the new length.  If INSErting
or DELEting from within assembly language code, any branches that need to be changed are changed for you automatically, and any
label that gets moved alters any code referring to that label in the same way as in MOVE; branches within 128 bytes that need to 
be changed get changed automatically, and any 3 byte command (other than BBR* and BBS*) that refers to a label being moved gets
changed appropriately.  These two commands take a lot of the pain out of assembly language programming, particularly when you're
debugging.


8.5) WORD, DWRD, BYTE, DBYT, STRIng, DSTR

Sometimes data needs to be entered within your code that isn't a 65c02 command.  Occasionally you'll want to mark an address as
being a word (ie 16 bit data) or a single byte of data.  For instance, the JSRFAR subroutine in the CX-16 API needs to be followed
by a word to indicate the address being jumped to, and a byte to indicate the block of paged memory.  Suppose you wanted to JSRFAR
to memory location A432 in block 1C of RAM:

JMPA JSRF	; calls JSRFAR
WORD A432	; address
BYTE 1C		; block of paged RAM

If you want to deallocate a WORD, just go to that address and type DWRD.  Similarly to deallocate a BYTE, just go to the address
and type DBYT.

Suppose you want to allocate a section of memory (up to 255 bytes) as a string.  To do so, first set a label at the first byte of the 
string, then at that address type

STRI

The editor will fill in NG and prompt you for the number of bytes in the string.  If you enter 00 then the function will abort to
the editor, and if a string had been allocated there it will be deallocated.  Otherwise the editor will declare that label to be
a string of length equal to the number of bytes you entered.

A more convenient way to deallocate a string is to go to the first byte in the string and type

DSTR

This will deallocate the memory as a string (by setting the string length to zero).  Any time a string is deallocated, any 
immediate mode command that points to a string length (see section 7.2.1) will also be deallocated.


8.6) LLBL

This function allows you to see all the labels and comments used in the editor itself.  The editor completely filled the memory
allocated for labels and comments in the DEFAULT.LBL file, so once you do this you cannot set any more labels or comments.
Typing LLBL a second time toggles the pointers back.  If you have set a bunch of labels and comments and then type LLBL, you will
have overwritten a number of the editor's comments or labels, so if you really want to see all of them it's best to do it before 
entering your own comments and labels, from a fresh run of EDIT.PRG.

Oh yeah, there's one undocumented function thrown in there as an Easter egg.  Just Enter the Frakkin Formula.


8.7) Branch to address pseudocommands

All branch commands on the 65c02 are to relative addresses.  The parameter is the relative address in two's complement notation,
so the byte represents an offset in the range -128 to +127.  That offset is calculated starting from the address of the command
following the branch command.

Figuring out the relative address can be done by simple counting if it's within a short range, or by subtracting the destination
address from the address of the command following the branch.

However, we're people, and want to do things the easy way.  For each of the following branch commands

BPL#, BMI#, BVC#, BVS#, BRAN, BCC#, BCS#, BNE#, BEQ#

There is a corresponding pseudocommand 

BPLA, BMIA, BVCA, BVSA, BRAA, BCCA, BCSA, BNEA, BEQA

These pseudocommands take an address or a label as a parameter, and convert it to the relative address for you.  In memory, the
regular branch command corresponding to the pseudocommand is stored, along with the correct relative address.

In editor mode 1, all these branches are displayed as if they were the pseudocommands, showing branches to an address or label.
In mode 2 however they are shown as the regular branch commands and relative addresses, exactly as they are stored in memory.
In either mode 1 or mode 2 you can type in either the regular branch command or the pseudocommand, the editor doesn't mind.

The BBR0..7 and BBS0..7 commands also have associated pseudocommands:

	BBR0..7: BR0A, BR1A, BR2A, BR3A, BR4A, BR5A, BR6A, BR7A
	BBS0..7: BS0A, BS1A, BS2A, BS3A, BS4A, BS5A, BS6A, BS7A

These pseudocommands can be used in place of BBR0..7 and BBS0..7; the editor will just expect an absolute address or a label
for the second parameter instead of a relative branch address.  The code is stored as the corresponding BBR0..7 or BBS0..7 code,
but only displayed that way in mode 2.  In mode 1 these commands are displayed as the pseudocommands, with branches to addresses.
In mode 2, if the zero page address referenced is attached to a label, then the label of that address is displayed instead of
the 2 hex digits for the address, and in mode 1 the zero page address is displayed as hex digits.

i.e. 	BR7A 02,addr in mode 1 would be displayed as BBR7 R0/L,hx in mode 2, 
where addr is the computed absolute address or corresponding label, and hx is two hex digits representing relative address.

If the zero page address used as a parameter in BBR* or BBS* or BR*A or BS*A happens to be attached to a label, then you can
enter the label when entering the command (see section 7.2.2):

i.e.	BR7A/R0/L,addr



-----------------------------------


9) Labels

When writing an assembly language program, you're usually not writing one huge program but rather hundreds of subroutines.
Many of those subroutines will have lots of JSRs and JMPs to these various subroutines.  Well, one hex address pretty much 
looks like any other, and it's easy to make mistakes jumping to the wrong address.

To make life easier for programmers, the editor allows you to set a label on an address.  The programmer can then use the label
anywhere one otherwise would have used the address.  This makes the program much more readable, as a series of JSRs is not to
obscure addresses but to slightly-less-obscure labels.

You can have up to 255 labels in your program.  There are two special labels that you must have in order to save your program,
FSTR and FEND, but the remaining 253 labels are yours.  There are also default labels for the Commodore Kernal, the CX-16 API,
the VERA registers, zero-page locations 02-21, and the 16 bit subroutines included with EDIT.PRG, plus a few more.  These default
labels are stored separately from your labels.

(The next version of the editor will have a lot more space allocated for labels using the paged RAM, so version 1.2 should have
room for about 2000 labels, which should be plenty.)


9.1) setting and deleting labels

A label is a four-character code starting with a letter, with the remaining characters being only letters, numbers, and the
symbols # + - / < >

To set a label (mode 1 or mode 2 only), move the cursor to the address you want to label and type

SLBL

Then enter the four character code you want for your label.

At least one of the four characters must not be hexadecimal; there has to be a letter higher than F or a symbol in the label.
Using BEEF as a label would be bad, because the parser wouldn't know if it referred to the hexadecimal address $BEEF or to the
label of the same name.  So, attempting to use a hex address as a label is not allowed by the editor.

Also, a label cannot duplicate an existing label; two addresses can't be named the same thing.  Attempting to set a label that
is already in use would be bad.  Try to imagine all life as you know it stopping instantaneously and every molecule in your body
exploding at the speed of light.  So, the editor won't allow it.

If the label file is full (for the current editor version, if the number of labels = 255) then the editor won't allow SLBL to
work at all.

If you want to change an existing label, just GOTO that label and type SLBL and the new label.  The new label is just stored
over the old one.

To delete a label, goto the label you want to delete and type

DLBL

and just like that, it's gone.  If you try do DLBL on an address that doesn't have a label or has a default label, nothing
happens.


9.2) Default labels

There are 231 labels set by default.  These labels are stored in MLEDIT.BIN, separate from your own labels.  They cannot be 
overwritten by user labels.  These labels correspond to the Commodore Kernal, the Commander X-16 API, the VERA registers, 
zero page labels, 16 bit subroutines, and various other useful subroutines and memory locations in EDIT.PRG.

There are 1901712 possible labels, and I've only used 231, so please don't tell me I "used all the good ones".


9.2.1) Commodore Kernal labels

There are 40 default labels that correspond to the Commodore Kernal jump vectors.  The source for these addresses and
subroutine names was the Commodore VIC-20 Programmer's Reference Guide (pages 182-210, highly recommended):

http://www.classiccmp.org/cini/pdf/Commodore/VIC-20%20Programmer%27s%20Reference%20Guide.pdf

Some of the original Kernal functions have been superseded or eliminated; only the ones currently in ROM are listed.  There
are some Commodore 128 Kernal functions also included.

The Kernal labels, their addresses, and corresponding Kernal subroutine names are as follows:


IECI	FFA5	IECIN – read byte from serial bus
IECO	FFA8	IECOUT – send byte to serial bus
CHKI	FFC6	CHKIN – set channel for character input
CHKO	FFC9	CHKOUT – set channel for character output
CHRI	FFCF	BASIN – get character
CHRO	FFD2	BSOUT – write character
CLAL	FFE7	CLALL – close all channels
CLOS	FFC3	CLOSE – close a channel
CLRC	FFCC	CLRCHN – restore character I/O to screen/keyboard
GETI	FFE4	GETIN – get character from keyboard
IOBA	FFF3	IOBASE – return start of I/O area
LSTN	FFB1	LISTEN – send listen command
LOAD	FFD5	LOAD – load a file into memory
MEMB	FF9C	MEMBOT – read/write address of start of usable RAM
MEMT	FF99	MEMTOP – read/write address of end of usable RAM
OPEN	FFC0	OPEN – open a channel
PLOT	FFF0	PLOT – read/write cursor position
RDTI	FFDE	RDTIM – read system clock
RDST	FFB7	READST – return status byte
SAVE	FFD8	SAVE – save a file from memory
SCND	FF93	SECOND – send LISTEN secondary address
SCRN	FFED	SCREEN – get the screen resolution
SLFS	FFBA	SETLFS – set logical, first, and secondary address
SMSG	FF90	SETMSG – set verbosity
SNAM	FFBD	SETNAM – set filename
STIM	FFDB	SETTIM – write system clock
STMO	FFA2	SETTIMO – set timeout (no function)
STOP	FFE1	STOP – test for stop key
TALK	FFB4	TALK – send TALK command
TKSA	FF96	TKSA – send TALK secondary address
UDTI	FFEA	UDTIM – advance clock
ULSN	FFAE	UNLSN – send UNLISTEN command
UTLK	FFAB	UNTLK – send UNTALK command
LUSA	FF8A	LKUPSA – search tables for given secondary address
CLOA	FF4A	CLOSE_ALL – close all files on a device
LULA	FF8D	LKUPLA – search tables for given logical address
FTCH	FF74	FETCH – LDA(fetvec), Y from any bank
STSH	FF77	STASH – STA(stavec),Y to any bank (currently non-functional)
CMPR	FF7A	CMPARE – CMP(cmpvec),Y to any bank (currently non-functional)
PRIM	FF7D	PRINM – print string following the caller's code
	


9.2.2) Commander X-16 API labels

The Commander X-16 is more than just a souped-up VIC-20 with more RAM.  It also has its own API.  The following are the 48
default labels assigned to the CX-16 API, the corresponding addresses, and the name listed in the CX-16 Programmer's
Reference guide.


CSDT	FF4D	clock_set_date_time – set date and time
CGDT	FF50	clock_get_date_time – get date and time
MOUC	FF68	mouse_config – configure mouse pointer
MOUG	FF6B	mouse_get – get state of mouse
JOYS	FF53	joystick_scan – query joysticks
JOYG	FF56	joystick_get – get state of one joystick
SPSI	FEF0	sprite_set_image – set the image of a sprite
SPSP	FEF3	sprite_set_position – set the position of a sprite
CINT	FF81	CINT – initialize VERA chip, upload PETSCII graphics character set
JSRF	FF6E	JSRFAR – execute a routine on another ROM or RAM bank
FBIN	FEF6	FB_init – enable graphics mode
FBGI	FEF9	FB_get_info – get screen size and color depth
FBSP	FEFC	FB_set_palette – set (parts of) the palette
FCPO	FEFF	FB_cursor_position – position the direct-access cursor
FCNL	FF02	FB_cursor_next_line – move direct-access cursor to next line
FGPX	FF05	FB_get_pixel – read one pixel, update cursor
FGPS	FF08	FB_get_pixels – copy pixels into RAM, update cursor
FSPX	FF0B	FB_set_pixel – set one pixel, update cursor
FSPS	FF0E	FB_set_pixels – copy pixels from RAM, update cursor
FS8P	FF11	FB_set_8_pixels – set 8 pixels from bit mask (transparent), update cursor
FS8O	FF14	FB_set_8_pixels_opaque – set 8 pixels from bit mask (opaque), update cursor
FFPX	FF17	FB_fill_pixels – fill pixels with constant color, update cursor
FBFP	FF1A	FB_filter_pixels – apply transform to pixels, update cursor
FBMP	FF1D	FB_move_pixels – copy horizontally consecutive pixels to a different position
GINI	FF20	GRAPH_init – initialize graphics
GCLS	FF23	GRAPH_clear – clear screen
GRSW	FF26	GRAPH_set_window set clipping region
GRSC	FF29	GRAPH_set_colors set stroke, fill, and background colors
GRDL	FF2C	GRAPH_draw_line – draw a line
GRDR	FF2F	GRAPH_draw_rect – draw a rectangle (optionally filled)
GRMR	FF32	GRAPH_move_rect – move pixels
GRDO	FF35	GRAPH_draw_oval – draw an oval or circle
GRDI	FF38	GRAPH_draw_image – draw a rectangular image
GRSF	FF3B	GRAPH_set_font – set the current font
GGCS	FF3E	GRAPH_get_char_size – get size and baseline of a character
GRPC	FF41	GRAPH_put char – print a character
CONI	FEDB	console_init – initialize console mode
CONP	FEDE	console_put_char – print character to console
CONG	FEE1	console_get_char – get character from console
MEMF	FEE4	memory_fill – fill memory region with a byte value
MEMC	FEE7	memory_copy – copy memory region
MCRC	FEEA	memory_crc – calculate CRC16 of memory region
MDCM	FEED	memory_decompress – decompress LZSA2 block
MONI	FF44	monitor – enter machine language monitor
RBAS	FF47	restore_basic – enter BASIC
SSCM	FF5F	set_screen_mode – set screen mode
SSCS	FF62	screen_set_charset – acrivate 8x8 text mode charset
PFNK	FF65	PFKEY – program a function key (not yet implemented)



9.2.3) VERA labels

The VERA video card has its own set of 32 labels.  Following is a list of those labels, their addresses, and VERA names;
check out the VERA Programmer's Reference guide for more details.

VELO	$9F20	VERA_ADDR_LO
VEMD	$9F21	VERA_ADDR_MID
VEHI	$9F22	VERA_ADDR_HI
VDT0	$9F23	VERA_DATA0
VDT1	$9F24	VERA_DATA1
VCON	$9F25	VERA_CTRL
VIEN	$9F26	VERA_IEN
VISR	$9F27	VERA_ISR
VIRQ	$9F28	IRQLINE_L
VVID	$9F29	DC_VIDEO (DCSEL=0)
VHSC	$9F2A	DC_HSCALE (DCSEL=0)
VVSC	$9F2B	DC_VSCALE (DCSEL=0)
VBOR	$9F2C	DC_BORDER (DCSEL=0)

(note: $9F29-$9F2C have different meanings when DCSEL=1, but the editor only allows one label per address.)

VL0C	$9F2D	L0_CONFIG
VL0M	$9F2E	L0_MAPBASE
VL0T	$9F2F	L0_TILEBASE
V0HL	$9F30	L0_HSCROLL_L
V0HH	$9F31	L0_HSCROLL_H
V0VL	$9F32	L0_VSCROLL_L
V0VH	$9F33	L0_VSCROLL_H
VL1C	$9F34	L1_CONFIG
VL1M	$9F35	L1_MAPBASE
VL1T	$9F36	L1_TILEBASE
V1HL	$9F37	L1_HSCROLL_L
V1HH	$9F38	L1_HSCROLL_H
V1VL	$9F39	L1_VSCROLL_L
V1VH	$9F3A	L1_VSCROLL_H
VAUC	$9F3B	AUDIO_CTRL
VAUR	$9F3C	AUDIO_RATE
VAUD	$9F3D	AUDIO_DATA
VSPD	$9F3E	SPI_DATA
VSPC	$9F3F	SPI_CTRL


9.2.4) Zero Page labels

The devs have suggested using some zero page addresses as 16 bit registers.  As well, the 16 bit functions (next section)
use some zero page locations as a 16 bit general purpose register and a 16 bit accumulator.  These 36 zero page
locations are given the default labels below.


R0/L	$0002	REG0
R0/H	$0003	
R1/L	$0004	REG1
R1/H	$0005	
R2/L	$0006	REG2
R2/H	$0007	
R3/L	$0008	REG3
R3/H	$0009	
R4/L	$000A	REG4
R4/H	$000B	
R5/L	$000C	REG5
R5/H	$000D	
R6/L	$000E	REG6
R6/H	$000F	
R7/L	$0010	REG7
R7/H	$0011	
R8/L	$0012	REG8
R8/H	$0013	
R9/L	$0014	REG9
R9/H	$0015	
RA/L	$0016	REGA
RA/H	$0017	
RB/L	$0018	REGB
RB/H	$0019	
RC/L	$001A	REGC
RC/H	$001B	
RD/L	$001C	REGD
RD/H	$001D	
RE/L	$001E	REGE
RE/H	$001F	
RF/L	$0020	REGF
RF/H	$0021	
RV/L	$007C	V (general purpose 16 bit register)
RV/H	$007D	
RW/L	$007E	W (16 bit accumulator)
RW/H	$007F	


9.2.5) 16 bit subroutine labels

These 41 subroutines are discussed in section 11 below and detailed fully in an alphabetical listing in Appendix C.

MVXY	$0612
MWXY	$0617
MXYV	$05F7
MXYW	$0553
R/OR	$0517
R/AN	$0523
RADD	$0583
RCMP	$05A2
REOR	$052F
RLW-	$0655
RLWV	$0666
RLWX	$065E
RLWY	$065C
RLXY	$0663
RMVW	$0550
RMVX	$05FD
RMWV	$05F4
RMWY	$061C
RMXV	$0605
RMYW	$0623
RMZV	$05EA
RMZW	$053D
RPHV	$05E3
RPLV	$05F0
RPHW	$055C
RPLW	$054C
RSUB	$0577
RSW-	$0673
RSWP	$0543
RSWV	$0684
RSWX	$067C
RSWY	$067A
RSXY	$0681
RV++	$05CF
RV--	$05D7
RW++	$0563
RW--	$056B
RWR<	$063B
RWR>	$0649
RWS<	$0631
RWS>	$0636



9.2.6) Other Default Labels

There are a number of subroutines that are not directly called by the user; they are used by the 16 bit subroutines.

CX2R	$04CF
CY2R	$04D8
GVMS	$04B2
GWMS	$04B6
IADD	$046F
ISUB	$0463
RFL/	$047C
RFLG	$05C6
RFLS	$04BD
RFLV	$0487
RFLW	$0498
RMOV	$04E1
RSCF	$04FC
RW<<	$04EE
RW>>	$0503


The location labeled HEXD ($0706) is a small lookup table of the PETSCII characters that correspond to the hex values 0-F.

There is a group of six labels that correspond to useful subroutines in the bootstrap code:  

SCLR ($0417)	- clears the screen

S180 ($041C)	- sets the logical address to 1, first address to 8, secondary address to zero.
		- useful when loading from disk.  Calling this saves you four bytes.

AYS/ ($0425)	- prints ARE YOU SURE?(Y/N) and waits for only Y or N
		- returns either 4E or 59 in the accumulator

PSTR ($043A)	- prints a string of length A pointed to by X (low byte) and Y (high byte)

PANY ($044B)	- prints PRESS ANY KEY TO CONTINUE and waits for a keypress

GKDB ($0452)	- Get Key with DeBounce
		- waits until no key is being pressed, then waits for a keypress and returns PETSCII result in A
		- result is also returned in address $0071


Finally, some other default labels are used for pointers by the assembly language editor; they had to be made default labels
because I simply ran out of room in the user label section.  In future versions of the editor these will not be default
labels.


CBUF	$07E0
NSLP	$84FF
NLBP	$87FF
NHBP	$8AFF
NLAB	$8CFF
NCOM	$8DFF
COMX	$8EFF
RCOM	$8FFF
RLAB	$90FF
RHBP	$91FF
NWRD	$9CFF
NBYT	$9EFF



9.3) FSTR and FEND

There are two special labels related to saving files with the editor, FSTR and FEND.  By default, FSTR is set at $0400 and
FEND is set to $0810.  FSTR points to the start of the file, and FEND is the address of the last byte in the file plus one.
The editor needs both of these labels to be set in order to save the file, or to insert, delete, or move blocks of code.
Be sure to delete FEND when you start programming, and then to set FEND at the last address of your program plus one byte
when you're done.

If you want your program to start at location $0801 instead of $0400 (i.e. you have no use for the functions in $0400-$07FF)
then goto $0400, delete FSTR, and then goto $0801 and SLBL FSTR.  Then once you save your program will start at $0801.  If
you do this, you won't be able to use any of the subroutines in EDIT.PRG and won't be able to use the editor on your program
anymore.  On the plus side, it means the user just has to enter LOAD"program_name" and RUN, not LOAD"program_name",8,1 and
RUN.  It's simplest just to leave FSTR where it is, but it's your computer and you're programming without a net, up to you.



-----------------------------------


10) Comments

There is space for 128 comments available for each program you write with this editor.  The bootstrap program starts with a
set of 5 default comments for some of the short useful subroutines available in $0400 - $080F.

Because there are so few comments available, and because each is limited to a maximum of 16 characters, your comments need
to be useful, concise, and sparse.  Comment only what you have to, and cram as much information into your comment as you can.
You're limited to using only letters, numbers, spaces, and the symbols + - # /  <  and >  so get creative.

Avoid useless comments; a comment like TRANSFER Y TO A is useless if the command it refers to is TYAI.  We can see that it is
transferring Y to A.  We're smart, not like everybody says.

A comment like JOY UP HANDLE is far more useful.  Be like JOY UP HANDLE.

To add a comment to an address, enter the command

COMM

The editor changes it to read COMMENT: and puts a semicolon and a cursor where you type your comment, to a maximum of 16
characters.  If a comment already existed at that address, it gets wiped out and replaced with the new comment.  If your
comment is less than 16 characters you can end it by pressing Return.  If the number of comments is already at the limit,
then COMM does nothing.

To delete a comment at an address, enter the command

DCOM

and the comment will be deleted.  If there was no comment at that address then nothing happens.



-----------------------------------


11) 16 bit subroutines

The Commander X-16 devs have suggested using zero page addresses 02 - 21 as sixteen 16-bit registers, named 
r0 through r15.  I have added default labels to each of those addresses: R0/L, R0/H .. RF/L, RF/H

Having these registers is fine, but we need a way to use them.  So, I have extended the devs' idea here a little.

First, consider all of the even zero page locations from 00 to 7E to potentially refer to a 16-bit register.  We
continue using the devs' suggestion, so register 10 would be at 22, register 11 would be at 24, and so on.
Register 3C would be at 7A, register 3D would be at 7C, register 3E at 7E, and register 3F is at 00.  This gives 
us up to 64 sixteen bit registers.

However, we won't use all of them as just dumb memory locations.  Zero page locations 7C and 7D (register 3D) are
set aside as register V, the sixteen bit version of X or Y.  Zero page locations 7E and 7F (register 3E) are then
register W, a sixteen bit accumulator.  And zero page locations 7A and 7B are set aside as a temporary flag
register and workspace, respectively.

That gives us 61 potential sixteen bit registers (but we'll probably mostly only use 0-F), a 16 bit version of X 
or Y, and a 16 bit version of A.

Included in the EDIT.PRG file are 41 functions that use V and W and the other 16 bit registers.  These functions
are almost all based on 65C02 8-bit counterparts, and all affect the Z,C,N, and V flags the same way as their 
8-bit counterparts do.  For instance, the 16 bit RADD function will behave the same way as ADC; Z will be set if
the result is zero, N will be set if the most significant bit is 1, and so forth.

The X and Y registers are used to pass parameters to and from the 16 bit subroutines.  They can each point to a
16 bit register, or can hold a 16 bit value with X as the low 8 bits and Y as the high 8 bits.  In some cases, 
X points to a register and Y is a memory offset.  If you are pointing to a register with X or Y, only the lowest
six bits of X or Y are used, and then that value is converted to the actual zero page address of the register.

The 16 bit functions can be roughly divided up into four groups: Input, Transfer, Process, and Output.

Input Functions bring information into the V and W registers from elsewhere in memory.

	RMZV	Set V to zero
	RMZW	Set W to zero
	RPLV	Pull V from the stack
	RPLW	Pull W from the stack
	MXYV	Move contents of X (low byte) and Y(high byte) into V
	MXYW	Move contents of X (low byte) and Y(high byte) into W
	RLXY	Move word at address stored in X (low byte) and Y(high byte) into W
	RLWV	Move word at address stored in V into W 
	RLWX	Move word at (address stored in 16 bit register pointed to by X) into W
	RLWY	Move word at (address stored in 16 bit register pointed to by Y) into W
	RLW-	Move word at ((address stored in 16 bit register pointed to by X) plus the Y offset) into W

Transfer Functions move data between V, W, and the other 16 bit registers.

	RMVW	Move V into W
	RMWV	Move W into V
	RSWP	Swap W and V
	RMXV	Move contents of register pointed to by X into V
	RMYW	Move contents of register pointed to by Y into W
	RMVX	Move V into register pointed to by X
	RMWY	Move W into register pointed to by Y

Process Functions perform arithmetic and logical operations on V and W.

	RSUB	Subtract W from V, store result in W
	RADD	Add W to V, store result in W
	RCMP	Compare V to W
	R/OR	V logical OR with W, result in W
	R/AN	V logical AND with W, result in W
	REOR	V logical exclusive-OR with W, result in W
	RV++	Increment V
	RV--	Decrement V
	RW++	Increment W
	RW--	Decrement W
	RWS<	Shift W left one bit
	RWS>	Shift W right one bit
	RWR<	Rotate W left one bit
	RWR>	Rotate W right one bit

Output Functions transfer information out of the 16 bit registers into memory.

	RPHV	Push V to the stack
	RPHW	Push W to the stack
	MVXY	Move contents of V into X (low byte) and Y(high byte)
	MWXY	Move contents of W into X (low byte) and Y(high byte)
	RSXY	Move W into word at address stored in X (low byte) and Y(high byte)
	RSWV	Move W into word at address stored in V
	RSWX	Move W into word at (address stored in 16 bit register pointed to by X)
	RSWY	Move W into word at (address stored in 16 bit register pointed to by Y)
	RSW-	Move W into word at ((address stored in 16 bit register pointed to by X) plus the Y offset)


As an example, let's add a 16 bit value to the word stored at some memory location, increment it, and store it in
a table at an offset.

	LDX#	04	;low 8 bits
	LDY#	3A	;high 8 bits
	JSRA	MXYV	;V is $3A04, augend
	LDX#	80	;destination table low byte
	LDY#	4C	;destination table high byte
	STX0	0A	;register 4 low byte
	STY0	0B	;register 4 high byte
	LDX#	9C	;low byte of address of addend
	LDY#	2D	;high byte of address of addend
	JSRA	RLXY	;load contents of address $2D9C into W, addend
	CLCF
	JSRA	RADD	;performs the 16 bit equivalent of ADC, result stored in W
	JSRA	RW++	;increments W
	LDX#	04	;register containing destination table address
	LDY#	A9	;offset
	JSRA	RSW-	;stores W at address contained in [register pointed to by X] plus Y (i.e. $4C80+$A9=$4D29,$4D2A) 

Each of these functions is listed in Appendix C, along with the registers and zero page memory used, the flags affected, and
the closest 8-bit analogue to the 16 bit function.



-----------------------------------


12) Future Work

The next version of the program will increase the amount of metadata associated with your program by a lot.  There will be
space for 2040 labels, 1280 comments, and similar increases in allocation for other metadata.  The metadata will all be
in paged RAM; I expect it to cover 5 or six blocks.

The next version might also be able to edit programs located in paged upper RAM. That's a stretch goal.

I'm sure that in a readme file of this length, I've probably screwed up somewhere. Expect any errors in this file to be 
corrected in the next version.  The editorREADME file will also be converted to HTML to make navigation easier.

There is no SD card support and no way of viewing the file directory.  That's probably going to have to wait a while, but
is an eventual goal.



-----------------------------------
-----------------------------------



Appendix A:  table of 65c02 commands

The following table lists the 4-character codes assigned to each command, along with the standard notation, # of bytes,
and # of cycles.  The table is sorted by opcode and tab-separated, so you can load it directly into your favorite spreadsheet.

More information available at https://www.westerndesigncenter.com/wdc/documentation/w65c02s.pdf
Detailed information about the new 65c02 commands is available at http://6502.org/tutorials/65c02opcodes.html
Lots more tutorials on assembly language programming are available at http://6502.org/tutorials/

legend:
	opcode : 4 character code			cycle notes:	a: +1 if crossing page boundary
	standard notation               				b: +1 if D flag is set
	#bytes, #cycles(notes)          				c: +1 if branch taken


00 : BRK0	01 : ORA+	02 : NOP2	03 : NOP1	04 : TSB0	05 : ORA0	06 : ASL0	07 : RMB0	08 : PHPI	09 : ORA#	0A : ASLI	0B : NOP1	0C : TSBA	0D : ORAA	0E : ASLA	0F : BBR0
BRK imp  	ORA (zp,X)	---     	---     	TSB zp  	ORA zp  	ASL zp  	RMB0 zp 	PHP imp 	ORA #   	ASL Acc 	---     	TSB abs 	ORA abs 	ASL abs 	BBR0 zp,rel
1byt, 7cyc	2byt, 2cyc	2byt, 2cyc	1byt, 1cyc	2byt, 5cyc	2byt, 3cyc	2byt, 5cyc	2byt, 5cyc	1byt, 3cyc	2byt, 2cyc	1byt, 2cyc	1byt, 1cyc	3byt, 6cyc	3byt, 4cyc	3byt, 6cyc	3byt, 5cyc
															
10 : BPL#	11 : ORA-	12 : ORA/	13 : NOP1	14 : TRB0	15 : ORAZ	16 : ASLZ	17 : RMB1	18 : CLCF	19 : ORAY	1A : INCI	1B : NOP1	1C : TRBA	1D : ORAX	1E : ASLX	1F : BBR1
BPL rel 	ORA (zp),Y	ORA (zp)	---     	TRB zp  	ORA zp,X	ASL zp,X	RMB1 zp 	CLC imp 	ORA abs,Y	INC Acc 	---     	TRB abs 	ORA abs,X	ASL abs,X	BBR1 zp,rel
2byt, 2cyc(ac)	2byt, 5cyc(a)	2byt, 5cyc	1byt, 1cyc	2byt, 5cyc	2byt, 4cyc	2byt, 6cyc	2byt, 5cyc	1byt, 2cyc	3byt, 4cyc(a)	1byt, 2cyc	1byt, 1cyc	3byt, 6cyc	3byt, 4cyc(a)	3byt, 6cyc(a)	3byt, 5cyc
															
20 : JSRA	21 : AND+	22 : NOP2	23 : NOP1	24 : BIT0	25 : AND0	26 : ROL0	27 : RMB2	28 : PLPI	29 : AND#	2A : ROLI	2B : NOP1	2C : BITA	2D : ANDA	2E : ROLA	2F : BBR2
JSR abs 	AND (zp,X)	---     	---     	BIT zp  	AND zp  	ROL zp  	RMB2 zp 	PLP imp 	AND #   	ROL Acc 	---     	BIT abs 	AND abs 	ROL abs 	BBR2 zp,rel
3byt, 6cyc	2byt, 6cyc	2byt, 2cyc	1byt, 1cyc	2byt, 3cyc	2byt, 3cyc	2byt, 5cyc	2byt, 5cyc	1byt, 4cyc	2byt, 2cyc	1byt, 2cyc	1byt, 1cyc	3byt, 4cyc	3byt, 4cyc	3byt, 6cyc	3byt, 5cyc
															
30 : BMI#	31 : AND-	32 : AND/	33 : NOP1	34 : BITZ	35 : ANDZ	36 : ROLZ	37 : RMB3	38 : SECF	39 : ANDY	3A : DECI	3B : NOP1	3C : BITX	3D : ANDX	3E : ROLX	3F : BBR3
BMI rel 	AND (zp),Y	AND (zp)	---     	BIT zp,X	AND zp,X	ROL zp,X	RMB3 zp 	SEC imp 	AND abs,Y	DEC Acc 	---     	BIT abs,X	AND abs,X	ROL abs,X	BBR3 zp,rel
2byt, 2cyc(ac)	2byt, 5cyc(a)	2byt, 5cyc	1byt, 1cyc	2byt, 4cyc	2byt, 4cyc	2byt, 6cyc	2byt, 5cyc	1byt, 2cyc	3byt, 4cyc(a)	1byt, 2cyc	1byt, 1cyc	3byt, 4cyc(a)	3byt, 4cyc(a)	3byt, 6cyc(a)	3byt, 5cyc
															
40 : RTII	41 : EOR+	42 : NOP2	43 : NOP1	44 : NOP2	45 : EOR0	46 : LSR0	47 : RMB4	48 : PHAI	49 : EOR#	4A : LSRI	4B : NOP1	4C : JMPA	4D : EORA	4E : LSRA	4F : BBR4
RTI imp 	EOR (zp,X)	---     	---     	---     	EOR zp  	LSR zp  	RMB4 zp 	PHA imp 	EOR #   	LSR Acc 	---     	JMP abs 	EOR abs 	LSR abs 	BBR4 zp,rel
1byt, 6cyc	2byt, 6cyc	2byt, 2cyc	1byt, 1cyc	2byt, 3cyc	2byt, 3cyc	2byt, 5cyc	2byt, 5cyc	1byt, 3cyc	2byt, 2cyc	1byt, 2cyc	1byt, 1cyc	3byt, 3cyc	3byt, 4cyc	3byt, 6cyc	3byt, 5cyc
															
50 : BVC#	51 : EOR-	52 : EOR/	53 : NOP1	54 : NOP2	55 : EORZ	56 : LSRZ	57 : RMB5	58 : CLID	59 : EORY	5A : PHYI	5B : NOP1	5C : NOP3	5D : EORX	5E : LSRX	5F : BBR5
BVC rel 	EOR (zp),Y	EOR (zp)	---     	---     	EOR zp,X	LSR zp,X	RMB5 zp 	CLI imp 	EOR abs,Y	PHY imp 	---     	---     	EOR abs,X	LSR abs,X	BBR5 zp,rel
2byt, 2cyc(ac)	2byt, 5cyc(a)	2byt, 5cyc	1byt, 1cyc	2byt, 4cyc	2byt, 4cyc	2byt, 6cyc	2byt, 5cyc	1byt, 2cyc	3byt, 4cyc(a)	1byt, 3cyc	1byt, 1cyc	3byt, 8cyc	3byt, 4cyc(a)	3byt, 6cyc(a)	3byt, 5cyc
															
60 : RTSI	61 : ADC+	62 : NOP2	63 : NOP1	64 : STZ0	65 : ADC0	66 : ROR0	67 : RMB6	68 : PLAI	69 : ADC#	6A : RORI	6B : NOP1	6C : JMPI	6D : ADCA	6E : RORA	6F : BBR6
RTS imp 	ADC (zp,X)	---     	---     	STZ zp  	ADC zp  	ROR zp  	RMB6 zp 	PLA imp 	ADC #   	ROR Acc 	---     	JMP ind 	ADC abs 	ROR abs 	BBR6 zp,rel
1byt, 6cyc	2byt, 6cyc(b)	2byt, 2cyc	1byt, 1cyc	2byt, 3cyc	2byt, 3cyc(b)	2byt, 5cyc	2byt, 5cyc	1byt, 4cyc	2byt, 2cyc(b)	1byt, 2cyc	1byt, 1cyc	3byt, 6cyc	3byt, 4cyc(b)	3byt, 6cyc	3byt, 5cyc
															
70 : BVS#	71 : ADC-	72 : ADC/	73 : NOP1	74 : STZZ	75 : ADCZ	76 : RORZ	77 : RMB7	78 : SEID	79 : ADCY	7A : PLYI	7B : NOP1	7C : JMPX	7D : ADCX	7E : RORX	7F : BBR7
BVS rel 	ADC (zp),Y	ADC (zp)	---     	STZ zp,X	ADC zp,X	ROR zp,X	RMB7 zp 	SEI imp 	ADC abs,Y	PLY imp 	---     	JMP abs,X	ADC abs,X	ROR abs,X	BBR7 zp,rel
2byt, 2cyc(ac)	2byt, 5cyc(ab)	2byt, 5cyc(b)	1byt, 1cyc	2byt, 4cyc	2byt, 4cyc(b)	2byt, 6cyc	2byt, 5cyc	1byt, 2cyc	3byt, 4cyc(ab)	1byt, 4cyc	1byt, 1cyc	3byt, 6cyc	3byt, 4cyc(ab)	3byt, 6cyc(a)	3byt, 5cyc
															
80 : BRAN	81 : STA+	82 : NOP2	83 : NOP1	84 : STY0	85 : STA0	86 : STX0	87 : SMB0	88 : DEYI	89 : BIT#	8A : TXAI	8B : NOP1	8C : STYA	8D : STAA	8E : STXA	8F : BBS0
BRA rel 	STA (zp,X)	---     	---     	STY zp  	STA zp  	STX zp  	SMB0 zp 	DEY imp 	BIT #   	TXA imp 	---     	STY abs 	STA abs 	STX abs 	BBS0 zp,rel
2byt, 3cyc(a)	2byt, 6cyc	2byt, 2cyc	1byt, 1cyc	2byt, 3cyc	2byt, 3cyc	2byt, 3cyc	2byt, 5cyc	1byt, 2cyc	2byt, 2cyc	1byt, 2cyc	1byt, 1cyc	3byt, 4cyc	3byt, 4cyc	3byt, 4cyc	3byt, 5cyc
															
90 : BCC#	91 : STA-	92 : STA/	93 : NOP1	94 : STYZ	95 : STAZ	96 : STXZ	97 : SMB1	98 : TYAI	99 : STAY	9A : TXSI	9B : NOP1	9C : STZA	9D : STAX	9E : STZX	9F : BBS1
BCC rel 	STA (zp),Y	STA (zp)	---     	STY zp,X	STA zp,X	STX zp,Y	SMB1 zp 	TYA imp 	STA abs,Y	TXS imp 	---     	STZ abs 	STA abs,X	STZ abs,X	BBS1 zp,rel
2byt, 2cyc(ac)	2byt, 6cyc	2byt, 5cyc	1byt, 1cyc	2byt, 4cyc	2byt, 4cyc	2byt, 4cyc	2byt, 5cyc	1byt, 2cyc	3byt, 5cyc	1byt, 2cyc	1byt, 1cyc	3byt, 4cyc	3byt, 5cyc	3byt, 5cyc	3byt, 5cyc
															
A0 : LDY#	A1 : LDA+	A2 : LDX#	A3 : NOP1	A4 : LDY0	A5 : LDA0	A6 : LDX0	A7 : SMB2	A8 : TAYI	A9 : LDA#	AA : TAXI	AB : NOP1	AC : LDYA	AD : LDAA	AE : LDXA	AF : BBS2
LDY #   	LDA (zp,X)	LDX #   	---     	LDY zp  	LDA zp  	LDX zp  	SMB2 zp 	TAY imp 	LDA #   	TAX imp 	---     	LDY abs 	LDA abs 	LDX abs 	BBS2 zp,rel
2byt, 2cyc	2byt, 6cyc	2byt, 2cyc	1byt, 1cyc	2byt, 3cyc	2byt, 3cyc	2byt, 3cyc	2byt, 5cyc	1byt, 2cyc	2byt, 2cyc	1byt, 2cyc	1byt, 1cyc	3byt, 4cyc	3byt, 4cyc	3byt, 4cyc	3byt, 5cyc
															
B0 : BCS#	B1 : LDA-	B2 : LDA/	B3 : NOP1	B4 : LDYZ	B5 : LDAZ	B6 : LDXZ	B7 : SMB3	B8 : CLVF	B9 : LDAY	BA : TSXI	BB : NOP1	BC : LDYX	BD : LDAX	BE : LDXY	BF : BBS3
BCS rel 	LDA (zp),Y	LDA (zp)	---     	LDY zp,X	LDA zp,X	LDX zp,Y	SMB3 zp 	CLV imp 	LDA abs,Y	TSX imp 	---     	LDY abs,X	LDA abs,X	LDX abs,Y	BBS3 zp,rel
2byt, 2cyc(ac)	2byt, 5cyc(a)	2byt, 5cyc	1byt, 1cyc	2byt, 4cyc	2byt, 4cyc	2byt, 4cyc	2byt, 5cyc	1byt, 2cyc	3byt, 4cyc(a)	1byt, 2cyc	1byt, 1cyc	3byt, 4cyc(a)	3byt, 4cyc(a)	3byt, 4cyc(a)	3byt, 5cyc
															
C0 : CPY#	C1 : CMP+	C2 : NOP2	C3 : NOP1	C4 : CPY0	C5 : CMP0	C6 : DEC0	C7 : SMB4	C8 : INYI	C9 : CMP#	CA : DEXI	CB : WAIT	CC : CPYA	CD : CMPA	CE : DECA	CF : BBS4
CPY #   	CMP (zp,X)	---     	---     	CPY zp  	CMP zp  	DEC zp  	SMB4 zp 	INY imp 	CMP #   	DEX imp 	WAI imp 	CPY abs 	CMP abs 	DEC abs 	BBS4 zp,rel
2byt, 2cyc	2byt, 6cyc	2byt, 2cyc	1byt, 1cyc	2byt, 3cyc	2byt, 3cyc	2byt, 5cyc	2byt, 5cyc	1byt, 2cyc	2byt, 2cyc	1byt, 2cyc	1byt, 3cyc	3byt, 4cyc	3byt, 4cyc	3byt, 6cyc	3byt, 5cyc
															
D0 : BNE#	D1 : CMP-	D2 : CMP/	D3 : NOP1	D4 : NOP2	D5 : CMPZ	D6 : DECZ	D7 : SMB5	D8 : CLDM	D9 : CMPY	DA : PHXI	DB : STOP	DC : NOP3	DD : CMPX	DE : DECX	DF : BBS5
BNE rel 	CMP (zp),Y	CMP (zp)	---     	---     	CMP zp,X	DEC zp,X	SMB5 zp 	CLD imp 	CMP abs,Y	PHX imp 	STP imp 	---     	CMP abs,X	DEC abs,X	BBS5 zp,rel
2byt, 2cyc(ac)	2byt, 5cyc(a)	2byt, 5cyc	1byt, 1cyc	2byt, 4cyc	2byt, 4cyc	2byt, 6cyc	2byt, 5cyc	1byt, 2cyc	3byt, 4cyc(a)	1byt, 3cyc	1byt, 3cyc	3byt, 4cyc	3byt, 4cyc(a)	3byt, 7cyc	3byt, 5cyc
															
E0 : CPX#	E1 : SBC+	E2 : NOP2	E3 : NOP1	E4 : CPX0	E5 : SBC0	E6 : INC0	E7 : SMB6	E8 : INXI	E9 : SBC#	EA : NOPE	EB : NOP1	EC : CPXA	ED : SBCA	EE : INCA	EF : BBS6
CPX #   	SBC (zp,X)	---     	---     	CPX zp  	SBC zp  	INC zp  	SMB6 zp 	INX imp 	SBC #   	NOP imp 	---     	CPX abs 	SBC abs 	INC abs 	BBS6 zp,rel
2byt, 2cyc	2byt, 6cyc(b)	2byt, 2cyc	1byt, 1cyc	2byt, 3cyc	2byt, 3cyc(b)	2byt, 5cyc	2byt, 5cyc	1byt, 2cyc	2byt, 2cyc(b)	1byt, 2cyc	1byt, 1cyc	3byt, 4cyc	3byt, 4cyc(b)	3byt, 6cyc	3byt, 5cyc
															
F0 : BEQ#	F1 : SBC-	F2 : SBC/	F3 : NOP1	F4 : NOP2	F5 : SBCZ	F6 : INCZ	F7 : SMB7	F8 : SEDM	F9 : SBCY	FA : PLXI	FB : NOP1	FC : NOP3	FD : SBCX	FE : INCX	FF : BBS7
BEQ rel 	SBC (zp),Y	SBC (zp)	---     	---     	SBC zp,X	INC zp,X	SMB7 zp 	SED imp 	SBC abs,Y	PLX imp 	---     	---     	SBC abs,X	INC abs,X	BBS7 zp,rel
2byt, 2cyc(ac)	2byt, 5cyc(ab)	2byt, 5cyc(b)	1byt, 1cyc	2byt, 4cyc	2byt, 4cyc(b)	2byt, 6cyc	2byt, 5cyc	1byt, 2cyc	3byt, 4cyc(ab)	1byt, 4cyc	1byt, 1cyc	3byt, 4cyc	3byt, 4cyc(ab)	3byt, 7cyc	3byt, 5cyc
															

-----------------------------------


Appendix B:  alphabetical list of 65c02 commands

This table lists all of the 65c02 commands in alphabetical order, including the addressing mode, opcode, 4-character code,
standard notation, # bytes, # cycles, and the flags affected by each command.  This table is tab-separated, so it can be loaded
into your favorite spreadsheet program.

There are 25 "pseudocommands" that allow branching to an address rather than relative branching; these commands do not exist on
the 65c02 but are included in the editor, which converts the branch to a relative address automatically.  In editor display mode 1
branches are shown as if they were these pseudocommands, but in editor display mode 2 they are shown as they are actually stored
in memory, as the standard relative branches.  These pseudocommands are shown with the addressing mode of {absolute}, with what 
would be the standard notation in curly braces {}, if these were real commands instead of stuff I made up.


cycle notes:	a: +1 if crossing page boundary
		b: +1 if D flag is set
		c: +1 if branch taken


ADC	add with carry					
						
	flag	effect				
	C	set if overflow in bit 7				
	Z	set if A = 0				
	V	set if sign bit is incorrect				
	N	set if bit 7 is set				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	Immediate 	$69	ADC#	ADC #   	2	2(b)
	Zero Page 	$65	ADC0	ADC zp  	2	3(b)
	Zero Page,X	$75	ADCZ	ADC zp,X	2	4(b)
	Absolute	$6D	ADCA	ADC abs 	3	4(b)
	Absolute,X	$7D	ADCX	ADC abs,X	3	4(ab)
	Absolute,Y	$79	ADCY	ADC abs,Y	3	4(ab)
	(Indirect,X)	$61	ADC+	ADC (zp,X)	2	6(b)
	(Indirect),Y	$71	ADC-	ADC (zp),Y	2	5(ab)
	(Indirect ZP)	$72	ADC/	ADC (zp)	2	5(b)
						
						
AND	logical AND					
						
	flag	effect				
	Z	set if A = 0				
	N	set if bit 7 is set				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	Immediate 	$29	AND#	AND #   	2	2
	Zero Page 	$25	AND0	AND zp  	2	3
	Zero Page,X	$35	ANDZ	AND zp,X	2	4
	Absolute	$2D	ANDA	AND abs 	3	4
	Absolute,X	$3D	ANDX	AND abs,X	3	4(a)
	Absolute,Y	$39	ANDY	AND abs,Y	3	4(a)
	(Indirect,X)	$21	AND+	AND (zp,X)	2	6
	(Indirect),Y	$31	AND-	AND (zp),Y	2	5(a)
	(Indirect ZP)	$32	AND/	AND (zp)	2	5
						
						
ASL	arithmetic shift left					
						
	flag	effect				
	C	set to contents of old bit 7				
	Z	set if A = 0				
	N	set if bit 7 is set				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	Accumulator	$0A	ASLI	ASL Acc 	1	2
	Zero Page 	$06	ASL0	ASL zp  	2	5
	Zero Page,X	$16	ASLZ	ASL zp,X	2	6
	Absolute	$0E	ASLA	ASL abs 	3	6
	Absolute,X	$1E	ASLX	ASL abs,X	3	6(a)
						
						
BBR	branch on bit reset					
						
	flag	effect				
	none	none				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	ZP, relative	$0F	BBR0	BBR0 zp,rel	3	5
	{ZP, absolute}	{$0F}	BR0A	{BBR0 zp,abs}	3	5
	ZP, relative	$1F	BBR1	BBR1 zp,rel	3	5
	{ZP, absolute}	{$1F}	BR1A	{BBR1 zp,abs}	3	5
	ZP, relative	$2F	BBR2	BBR2 zp,rel	3	5
	{ZP, absolute}	{$2F}	BR2A	{BBR2 zp,abs}	3	5
	ZP, relative	$3F	BBR3	BBR3 zp,rel	3	5
	{ZP, absolute}	{$3F}	BR3A	{BBR3 zp,abs}	3	5
	ZP, relative	$4F	BBR4	BBR4 zp,rel	3	5
	{ZP, absolute}	{$4F}	BR4A	{BBR4 zp,abs}	3	5
	ZP, relative	$5F	BBR5	BBR5 zp,rel	3	5
	{ZP, absolute}	{$5F}	BR5A	{BBR5 zp,abs}	3	5
	ZP, relative	$6F	BBR6	BBR6 zp,rel	3	5
	{ZP, absolute}	{$6F}	BR6A	{BBR6 zp,abs}	3	5
	ZP, relative	$7F	BBR7	BBR7 zp,rel	3	5
	{ZP, absolute}	{$7F}	BR7A	{BBR7 zp,abs}	3	5
						
						
BBS	branch on bit set					
						
	flag	effect				
	none	none				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	ZP, relative	$8F	BBS0	BBS0 zp,rel	3	5
	{ZP, absolute}	{$8F}	BS0A	{BBS0 zp,abs}	3	5
	ZP, relative	$9F	BBS1	BBS1 zp,rel	3	5
	{ZP, absolute}	{$9F}	BS1A	{BBS1 zp,abs}	3	5
	ZP, relative	$AF	BBS2	BBS2 zp,rel	3	5
	{ZP, absolute}	{$AF}	BS2A	{BBS2 zp,abs}	3	5
	ZP, relative	$BF	BBS3	BBS3 zp,rel	3	5
	{ZP, absolute}	{$BF}	BS3A	{BBS3 zp,abs}	3	5
	ZP, relative	$CF	BBS4	BBS4 zp,rel	3	5
	{ZP, absolute}	{$CF}	BS4A	{BBS4 zp,abs}	3	5
	ZP, relative	$DF	BBS5	BBS5 zp,rel	3	5
	{ZP, absolute}	{$DF}	BS5A	{BBS5 zp,abs}	3	5
	ZP, relative	$EF	BBS6	BBS6 zp,rel	3	5
	{ZP, absolute}	{$EF}	BS6A	{BBS6 zp,abs}	3	5
	ZP, relative	$FF	BBS7	BBS7 zp,rel	3	5
	{ZP, absolute}	{$FF}	BS7A	{BBS7 zp,abs}	3	5
						
						
BCC	branch if carry clear (i.e. if C=0)					
						
	flag	effect				
	none	none				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	relative	$90	BCC#	BCC rel 	2	2(ac)
	{absolute}	{$90}	BCCA	{BCC abs}	2	2(ac)
						
						
BCS	branch if carry set (i.e. if C=1)					
						
	flag	effect				
	none	none				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	relative	$B0	BCS#	BCS rel 	2	2(ac)
	{absolute}	{$B0}	BCSA	{BCS abs}	2	2(ac)	
					
						
BEQ	branch if equal (i.e. if Z=1)			
						
	flag	effect				
	none	none				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	relative	$F0	BEQ#	BEQ rel 	2	2(ac)
	{absolute}	{$F0}	BEQA	{BEQ abs}	2	2(ac)
						
						
BIT	bit test					
						
	flag	effect				
	Z	set if the result of the AND is zero				
	V	set to bit 6 of the memory value				
	N	set to bit 7 of the memory value				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	Immediate 	$89	BIT#	BIT #   	2	2
	Zero Page 	$24	BIT0	BIT zp  	2	3
	Zero Page,X	$34	BITZ	BIT zp,X	2	4
	Absolute	$2C	BITA	BIT abs 	3	4
	Absolute,X	$3C	BITX	BIT abs,X	3	4(a)
						
						
BMI	branch if minus (i.e. if N=1)					
						
	flag	effect				
	none	none				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	relative	$30	BMI#	BMI rel 	2	2(ac)
	{absolute}	{$30}	BMIA	{BMI abs}	2	2(ac)
						
						
BNE	branch if not equal (i.e. if Z=0)					
						
	flag	effect				
	none	none				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	relative	$D0	BNE#	BNE rel 	2	2(ac)
	{absolute}	{$D0}	BNEA	{BNE abs}	2	2(ac)
						
						
BPL	branch if positive (i.e. if N=0)				
						
	flag	effect				
	none	none				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	relative	$10	BPL#	BPL rel 	2	2(ac)
	{absolute}	{$10}	BPLA	{BPL abs}	2	2(ac)
						
						
BRA	branch always					
						
	flag	effect				
	none	none				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	relative	$80	BRAN	BRA rel 	2	3(a)
	{absolute}	{$80}	BRAA	{BRA abs}	2	2(ac)
						
						
BRK	force interrupt					
						
	flag	effect				
	B	set to 1				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	implied 	$00	BRK0	BRK imp 	1	7
						
						
BVC	branch if overflow clear					
						
	flag	effect				
	none	none				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	relative	$50	BVC#	BVC rel 	2	2(ac)
	{absolute}	{$50}	BVCA	{BVC abs}	2	2(ac)	
					
						
BVS	branch if overflow set					
						
	flag	effect				
	none	none				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	relative	$70	BVS#	BVS rel 	2	2(ac)
	{absolute}	{$70}	BVSA	{BVS abs}	2	2(ac)
						
						
CLC	clear carry flag					
						
	flag	effect				
	C	set to 0				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	implied 	$18	CLCF	CLC imp 	1	2
						
						
CLD	clear decimal mode flag					
						
	flag	effect				
	D	set to 0				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	implied 	$D8	CLDM	CLD imp 	1	2
						
						
CLI	clear interrupt disable					
						
	flag	effect				
	I	set to 0				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	implied 	$58	CLID	CLI imp 	1	2
						
						
CLV	clear overflow flag					
						
	flag	effect				
	V	set to 0				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	implied 	$B8	CLVF	CLV imp 	1	2


CMP	compare accumulator					
						
	flag	effect				
	C	set if A>=M				
	Z	set if A=M				
	N	set if bit 7 of the result is set				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	Immediate 	$C9	CMP#	CMP #   	2	2
	Zero Page 	$C5	CMP0	CMP zp  	2	3
	Zero Page,X	$D5	CMPZ	CMP zp,X	2	4
	Absolute	$CD	CMPA	CMP abs 	3	4
	Absolute,X	$DD	CMPX	CMP abs,X	3	4(a)
	Absolute,Y	$D9	CMPY	CMP abs,Y	3	4(a)
	(Indirect,X)	$C1	CMP+	CMP (zp,X)	2	6
	(Indirect),Y	$D1	CMP-	CMP (zp),Y	2	5(a)
	(Indirect ZP)	$D2	CMP/	CMP (zp)	2	5
						
						
CPX	compare X register					
						
	flag	effect				
	C	set if X>=M				
	Z	set if X=M				
	N	set if bit 7 of the result is set				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	Immediate 	$E0	CPX#	CPX #   	2	2
	Zero Page 	$E4	CPX0	CPX zp  	2	3
	Absolute	$EC	CPXA	CPX abs 	3	4
						
						
CPY	compare Y register					
						
	flag	effect				
	C	set if Y>=M				
	Z	set if Y=M				
	N	set if bit 7 of the result is set				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	Immediate 	$C0	CPY#	CPY #   	2	2
	Zero Page 	$C4	CPY0	CPY zp  	2	3
	Absolute	$CC	CPYA	CPY abs 	3	4
						
						
DEC	decrement memory					
						
	flag	effect				
	Z	set if result is zero				
	N	set if bit 7 of the result is set				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	Accumulator	$3A	DECI	DEC Acc 	1	2
	Zero Page 	$C6	DEC0	DEC zp  	2	5
	Zero Page,X	$D6	DECZ	DEC zp,X	2	6
	Absolute	$CE	DECA	DEC abs 	3	6
	Absolute,X	$DE	DECX	DEC abs,X	3	7
						
						
DEX	decrement X register					
						
	flag	effect				
	Z	set if X is zero				
	N	set if bit 7 of X is set				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	Implied 	$CA	DEXI	DEX imp 	1	2
						
						
DEY	decrement Y register					
						
	flag	effect				
	Z	set if Y is zero				
	N	set if bit 7 of Y is set				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	Implied 	$88	DEYI	DEY imp 	1	2
						
						
EOR	exclusive OR					
						
	flag	effect				
	Z	set if A is zero				
	N	set if bit 7 is set				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	Immediate 	$49	EOR#	EOR #   	2	2
	Zero Page 	$45	EOR0	EOR zp  	2	3
	Zero Page,X	$55	EORZ	EOR zp,X	2	4
	Absolute	$4D	EORA	EOR abs 	3	4
	Absolute,X	$5D	EORX	EOR abs,X	3	4(a)
	Absolute,Y	$59	EORY	EOR abs,Y	3	4(a)
	(Indirect,X)	$41	EOR+	EOR (zp,X)	2	6
	(Indirect),Y	$51	EOR-	EOR (zp),Y	2	5(a)
	(Indirect ZP)	$52	EOR/	EOR (zp)	2	5
						
						
INC	increment memory					
						
	flag	effect				
	Z	set if result is zero				
	N	set if bit 7 of the result is set				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	Accumulator	$1A	INCI	INC Acc 	1	2
	Zero Page 	$E6	INC0	INC zp  	2	5
	Zero Page,X	$F6	INCZ	INC zp,X	2	6
	Absolute	$EE	INCA	INC abs 	3	6
	Absolute,X	$FE	INCX	INC abs,X	3	7
						
						
INX	increment X register					
						
	flag	effect				
	Z	set if X is zero				
	N	set if bit 7 of X is set				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	Implied 	$E8	INXI	INX imp 	1	2
						
						
INY	increment Y register					
						
	flag	effect				
	Z	set if Y is zero				
	N	set if bit 7 of Y is set				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	Implied 	$C8	INYI	INY imp 	1	2
						
						
JMP	jump					
						
	flag	effect				
	none	none				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	Absolute	$4C	JMPA	JMP abs 	3	3
	Indirect	$6C	JMPI	JMP ind 	3	6
	Absolute,X	$7C	JMPX	JMP abs,X	3	6
						
						
JSR	jump to subroutine					
						
	flag	effect				
	none	none				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	Absolute	$20	JSRA	JSR abs 	3	6
						
						
LDA	load accumulator					
						
	flag	effect				
	Z	set if A is zero				
	N	set if bit 7 of A is set				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	Immediate 	$A9	LDA#	LDA #   	2	2
	Zero Page 	$A5	LDA0	LDA zp  	2	3
	Zero Page,X	$B5	LDAZ	LDA zp,X	2	4
	Absolute	$AD	LDAA	LDA abs 	3	4
	Absolute,X	$BD	LDAX	LDA abs,X	3	4(a)
	Absolute,Y	$B9	LDAY	LDA abs,Y	3	4(a)
	(Indirect,X)	$A1	LDA+	LDA (zp,X)	2	6
	(Indirect),Y	$B1	LDA-	LDA (zp),Y	2	5(a)
	(Indirect ZP)	$B2	LDA/	LDA (zp)	2	5
						
						
LDX	load X register					
						
	flag	effect				
	Z	set if X is zero				
	N	set if bit 7 of X is set				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	Immediate 	$A2	LDX#	LDX #   	2	2
	Zero Page 	$A6	LDX0	LDX zp  	2	3
	Zero Page,Y	$B6	LDXZ	LDX zp,Y	2	4
	Absolute	$AE	LDXA	LDX abs 	3	4
	Absolute,Y	$BE	LDXY	LDX abs,Y	3	4(a)
						
						
LDY	load Y register					
						
	flag	effect				
	Z	set if Y is zero				
	N	set if bit 7 of Y is set				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	Immediate 	$A0	LDY#	LDY #   	2	2
	Zero Page 	$A4	LDY0	LDY zp  	2	3
	Zero Page,X	$B4	LDYZ	LDY zp,X	2	4
	Absolute	$AC	LDYA	LDY abs 	3	4
	Absolute,X	$BC	LDYX	LDY abs,X	3	4(a)
						
						
LSR	logical shift right					
						
	flag	effect				
	C	set to contents of old bit 0				
	Z	set if result is zero				
	N	set if bit 7 of the result is set				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	Accumulator	$4A	LSRI	LSR Acc 	1	2
	Zero Page 	$46	LSR0	LSR zp  	2	5
	Zero Page,X	$56	LSRZ	LSR zp,X	2	6
	Absolute	$4E	LSRA	LSR abs 	3	6
	Absolute,X	$5E	LSRX	LSR abs,X	3	6(a)
						
						
NOP	no operation					
						
	flag	effect				
	none	none				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	Implied 	$EA	NOPE	NOP imp 	1	2
						
						
ORA	logical inclusive OR					
						
	flag	effect				
	Z	set if A is zero				
	N	set if bit 7 is set				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	Immediate 	$09	ORA#	ORA #   	2	2
	Zero Page 	$05	ORA0	ORA zp  	2	3
	Zero Page,X	$15	ORAZ	ORA zp,X	2	4
	Absolute	$0D	ORAA	ORA abs 	3	4
	Absolute,X	$1D	ORAX	ORA abs,X	3	4(a)
	Absolute,Y	$19	ORAY	ORA abs,Y	3	4(a)
	(Indirect,X)	$01	ORA+	ORA (zp,X)	2	2
	(Indirect),Y	$11	ORA-	ORA (zp),Y	2	5(a)
	(Indirect ZP)	$12	ORA/	ORA (zp)	2	5


PHA	push accumulator					
						
	flag	effect				
	none	none				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	Implied 	$48	PHAI	PHA imp 	1	3
						
						
PHP	push processor status					
						
	flag	effect				
	none	none				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	Implied 	$08	PHPI	PHP imp 	1	3
						
						
PHX	push X register					
						
	flag	effect				
	none	none				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	Implied 	$DA	PHXI	PHX imp 	1	3
						
						
PHY	push Y register					
						
	flag	effect				
	none	none				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	Implied 	$5A	PHYI	PHY imp 	1	3
						
						
PLA	pull accumulator					
						
	flag	effect				
	Z	set if A=0				
	N	set if bit 7 of A is set				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	Implied 	$68	PLAI	PLA imp 	1	4
						
						
PLP	pull processor status					
						
	flag	effect				
	C	set from stack				
	Z	set from stack				
	I	set from stack				
	D	set from stack				
	B	set from stack				
	V	set from stack				
	N	set from stack				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	Implied 	$28	PLPI	PLP imp 	1	4
						
						
PLX	pull X register					
						
	flag	effect				
	Z	set if X=0				
	N	set if bit 7 of X is set				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	Implied 	$FA	PLXI	PLX imp 	1	4
						
						
PLY	pull Y register					
						
	flag	effect				
	Z	set if Y=0				
	N	set if bit 7 of Y is set				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	Implied 	$7A	PLYI	PLY imp 	1	4
						
						
RMB	reset memory bit					
						
	flag	effect				
	none	none				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	Zero Page	$07	RMB0	RMB0 zp 	2	5
	Zero Page	$17	RMB1	RMB1 zp 	2	5
	Zero Page	$27	RMB2	RMB2 zp 	2	5
	Zero Page	$37	RMB3	RMB3 zp 	2	5
	Zero Page	$47	RMB4	RMB4 zp 	2	5
	Zero Page	$57	RMB5	RMB5 zp 	2	5
	Zero Page	$67	RMB6	RMB6 zp 	2	5
	Zero Page	$77	RMB7	RMB7 zp 	2	5
						
						
ROL	rotate left					
						
	flag	effect				
	C	set to contents of old bit 7				
	Z	set if A=0				
	N	set if bit 7 of the result is set				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	Accumulator	$2A	ROLI	ROL Acc 	1	2
	Zero Page 	$26	ROL0	ROL zp  	2	5
	Zero Page,X	$36	ROLZ	ROL zp,X	2	6
	Absolute	$2E	ROLA	ROL abs 	3	6
	Absolute,X	$3E	ROLX	ROL abs,X	3	6(a)
						
						
ROR	rotate right					
						
	flag	effect				
	C	set to contents of old bit 0				
	Z	set if A=0				
	N	set if bit 7 of the result is set				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	Accumulator	$6A	RORI	ROR Acc 	1	2
	Zero Page 	$66	ROR0	ROR zp  	2	5
	Zero Page,X	$76	RORZ	ROR zp,X	2	6
	Absolute	$6E	RORA	ROR abs 	3	6
	Absolute,X	$7E	RORX	ROR abs,X	3	6(a)
						
						
RTI	return from interrupt					
						
	flag	effect				
	C	set from stack				
	Z	set from stack				
	I	set from stack				
	D	set from stack				
	B	set from stack				
	V	set from stack				
	N	set from stack				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	Implied 	$40	RTII	RTI imp 	1	6
						
						
RTS	return from subroutine					
						
	flag	effect				
	none	none				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	Implied 	$60	RTSI	RTS imp 	1	6
						
						
SBC	subtract with carry					
						
	flag	effect				
	C	set if overflow in bit 7				
	Z	set if A = 0				
	V	set if sign bit is incorrect				
	N	set if bit 7 is set				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	Immediate 	$E9	SBC#	SBC #   	2	2(b)
	Zero Page 	$E5	SBC0	SBC zp  	2	3(b)
	Zero Page,X	$F5	SBCZ	SBC zp,X	2	4(b)
	Absolute	$ED	SBCA	SBC abs 	3	4(b)
	Absolute,X	$FD	SBCX	SBC abs,X	3	4(ab)
	Absolute,Y	$F9	SBCY	SBC abs,Y	3	4(ab)
	(Indirect,X)	$E1	SBC+	SBC (zp,X)	2	6(b)
	(Indirect),Y	$F1	SBC-	SBC (zp),Y	2	5(ab)
	(Indirect ZP)	$F2	SBC/	SBC (zp)	2	5(b)
						
						
SEC	set carry flag					
						
	flag	effect				
	C	set to 1				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	Implied 	$38	SECF	SEC imp 	1	2
						
						
SED	set decimal mode flag					
						
	flag	effect				
	D	set to 1				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	Implied 	$F8	SEDM	SED imp 	1	2
						
						
SEI	set interrupt disable					
						
	flag	effect				
	I	set to 1				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	Implied 	$78	SEID	SEI imp 	1	2
						
						
SMB	set memory bit					
						
	flag	effect				
	none	none				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	Zero Page	$87	SMB0	SMB0 zp 	2	5
	Zero Page	$97	SMB1	SMB1 zp 	2	5
	Zero Page	$A7	SMB2	SMB2 zp 	2	5
	Zero Page	$B7	SMB3	SMB3 zp 	2	5
	Zero Page	$C7	SMB4	SMB4 zp 	2	5
	Zero Page	$D7	SMB5	SMB5 zp 	2	5
	Zero Page	$E7	SMB6	SMB6 zp 	2	5
	Zero Page	$F7	SMB7	SMB7 zp 	2	5
						
						
STA	store accumulator					
						
	flag	effect				
	none	none				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	Zero Page 	$85	STA0	STA zp  	2	3
	Zero Page,X	$95	STAZ	STA zp,X	2	4
	Absolute	$8D	STAA	STA abs 	3	4
	Absolute,X	$9D	STAX	STA abs,X	3	5
	Absolute,Y	$99	STAY	STA abs,Y	3	5
	(Indirect,X)	$81	STA+	STA (zp,X)	2	6
	(Indirect),Y	$91	STA-	STA (zp),Y	2	6
	(Indirect ZP)	$92	STA/	STA (zp)	2	5
						
						
STP	stop					
						
	flag	effect				
	none	none				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	Implied 	$DB	STOP	STP imp 	1	3
						
						
STX	store X register					
						
	flag	effect				
	none	none				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	Zero Page 	$86	STX0	STX zp  	2	3
	Zero Page,Y	$96	STXZ	STX zp,Y	2	4
	Absolute	$8E	STXA	STX abs 	3	4
						
						
STY	store Y register					
						
	flag	effect				
	none	none				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	Zero Page 	$84	STY0	STY zp  	2	3
	Zero Page,X	$94	STYZ	STY zp,X	2	4
	Absolute	$8C	STYA	STY abs 	3	4
						
						
STZ	Store zero in memory					
						
	flag	effect				
	none	none				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	Zero Page 	$64	STZ0	STZ zp  	2	3
	Zero Page,X	$74	STZZ	STZ zp,X	2	4
	Absolute	$9C	STZA	STZ abs 	3	4
	Absolute,X	$9E	STZX	STZ abs,X	3	5
						
						
TAX	transfer accumulator to X					
						
	flag	effect				
	Z	set if X=0				
	N	set if bit 7 of X is set				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	Implied 	$AA	TAXI	TAX imp 	1	2
						
						
TAY	transfer accumulator to Y					
						
	flag	effect				
	Z	set if Y=0				
	N	set if bit 7 of Y is set				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	Implied 	$A8	TAYI	TAY imp 	1	2
						
						
TRB	test and reset bits					
						
	flag	effect				
	Z	set if the memory value held any of the specified bits				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	Zero Page 	$14	TRB0	TRB zp  	2	5
	Absolute	$1C	TRBA	TRB abs 	3	6
						
						
TSB	test and set bits					
						
	flag	effect				
	Z	set if the memory value held any of the specified bits				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	Zero Page 	$04	TSB0	TSB zp  	2	5
	Absolute	$0C	TSBA	TSB abs 	3	6
						
						
TSX	transfer stack pointer to X					
						
	flag	effect				
	Z	set if X=0				
	N	set if bit 7 of X is set				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	Implied 	$BA	TSXI	TSX imp 	1	2
						
						
TXA	transfer X to accumulator					
						
	flag	effect				
	Z	set if A=0				
	N	set if bit 7 of A is set				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	Implied 	$8A	TXAI	TXA imp 	1	2
						
						
TXS	transfer X to stack pointer					
						
	flag	effect				
	none	none				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	Implied 	$9A	TXSI	TXS imp 	1	2
						
						
TYA	transfer Y to accumulator					
						
	flag	effect				
	Z	set if A=0				
	N	set if bit 7 of A is set				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	Implied 	$98	TYAI	TYA imp 	1	2
						
						
WAI	wait for interrupt					
						
	flag	effect				
	B	set to 1				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	Implied 	$CB	WAIT	WAI imp 	1	3



-----------------------------------


Appendix C:  alphabetical list of 16 bit functions

The following subroutines are located in the address range $0464 to $068E, as part of the EDIT.PRG bootstrap program.
These subroutines use zero page locations 7C and 7D as a 16 bit register V - analogous to X or Y - and locations
7E and 7F as a 16 bit accumulator W, which operates similarly to A.  Most of the routines also use location 7A as a 
flag bitmask, and some use 7B as temporary flag storage.  Almost all of the subroutines use X and Y to communicate with
the rest of your program.  Section 14 above describes these functions more generally.

The table below lists the 16 bit subroutines alphabetically, along with their location in memory, a symbolic and written
description of the operation of the subroutine, a list of all registers and memory locations used as input, workspace,
and subroutine output, the flags affected by the subroutine, and the closest 8-bit equivalent 65c02 command, listed both
as the 4 character code used by this editor and also as the standard notation.

The REGX and REGY in the table below refer to the 16 bit registers pointed to by X and Y, respectively.  For instance,
if X=00 and Y=0C, then REGX is address $0002 and REGY is address $001A.


MVXY	V --> X,Y	Move contents of V into X (low byte) and Y(high byte)		
$0612	inputs		none	
	uses		X, Y, V, A, $7A	
	outputs		X, Y	
				
	flag		effect	
	Z		set if Y is zero	
	N		set if MSB of Y is set	
				
	8 bit analogue:	4 char		TAXI, TAYI
			standard	TAX, TAY
				
				
MWXY	W --> X,Y	Move contents of W into X (low byte) and Y(high byte)		
$0617	inputs		none	
	uses		X, Y, W, A, $7A	
	outputs		X, Y	
				
	flag		effect	
	Z		set if Y is zero	
	N		set if MSB of Y is set	
				
	8 bit analogue:	4 char		TAXI, TAYI
			standard	TAX, TAY
				
				
MXYV	X,Y --> V	Move contents of X (low byte) and Y(high byte) into V		
$05F7	inputs		X, Y	
	uses		X, Y, V, A, $7A	
	outputs		V	
				
	flag		effect	
	Z		set if V is zero	
	N		set if MSB of V is set	
				
	8 bit analogue:	4 char		LDY#
			standard	LDY #
				
				
MXYW	X,Y --> W	Move contents of X (low byte) and Y(high byte) into W		
$0553	inputs		X, Y	
	uses		X, Y, W, A, $7A	
	outputs		W	
				
	flag		effect	
	Z		set if W is zero	
	N		set if MSB of W is set	
				
	8 bit analogue:	4 char		LDA#
			standard	LDA #
				
				
R/AN	V AND W --> W	V logical AND with W, result in W		
$0523	inputs		none	
	uses		X, Y, A, V, W, $7A	
	outputs		W	
				
	flag		effect	
	Z		set if W is zero	
	N		set if MSB of W is set	
				
	8 bit analogue:	4 char		AND#
			standard	AND #
				
				
R/OR	V OR W --> W	V logical OR with W, result in W		
$0517	inputs		none	
	uses		X, Y, A, V, W, $7A	
	outputs		W	
				
	flag		effect	
	Z		set if W is zero	
	N		set if MSB of W is set	
				
	8 bit analogue:	4 char		ORA#
			standard	ORA #
				
				
RADD	V + W --> W	Add W to V, store result in W		
$0583	inputs		none	
	uses		X, Y, A, V, W, $7A, $7B	
	outputs		W	
				
	flag		effect	
	Z		set if V = W	
	N		MSB of result of addition	
	C		set if overflow in result	
	V		set if sign bit is wrong	
				
	8 bit analogue:	4 char		ADC#
			standard	ADC #
				
				
RCMP	V - W      	Compare V to W		
$05A2	inputs		none	
	uses		X, Y, A, V, W, $7A, $7B	
	outputs		just flags	
				
	flag		effect	
	Z		set if V = W	
	N		MSB of result of subtraction	
	C		set if V >= W	
				
	8 bit analogue:	4 char		CMP#
			standard	CMP #
				
				
REOR	V EOR W --> W	V logical exclusive-OR with W, result in W		
$052F	inputs		none	
	uses		X, Y, A, V, W, $7A	
	outputs		W	
				
	flag		effect	
	Z		set if W is zero	
	N		set if MSB of W is set	
				
	8 bit analogue:	4 char		EOR#
			standard	EOR #
				
				
RLW-	[[REGX]+Y]-->W	Move word at ((address stored in 16 bit register pointed to by X) plus the Y offset) into W		
$0655	inputs		X, Y	
	uses		X, Y, V, A, $7A	
	outputs		W	
				
	flag		effect	
	Z		set if W is zero	
	N		set if MSB of W is set	
				
	8 bit analogue:	4 char		LDA-
			standard	LDA (zp),Y
				
				
RLWV	[V] -->W    	Move word at address stored in V into W 		
$0666	inputs		none	
	uses		X, Y, V, A, $7A	
	outputs		W	
				
	flag		effect	
	Z		set if W is zero	
	N		set if MSB of W is set	
				
	8 bit analogue:	4 char		LDA/
			standard	LDA (zp)
				
				
RLWX	[REGX] --> W	Move word at (address stored in 16 bit register pointed to by X) into W		
$065E	inputs		X	
	uses		X, Y, V, A, $7A	
	outputs		W	
				
	flag		effect	
	Z		set if V is zero	
	N		set if MSB of V is set	
				
	8 bit analogue:	4 char		LDA+
			standard	LDA (zp,X)
				
				
RLWY	[REGY] --> W	Move word at (address stored in 16 bit register pointed to by Y) into W		
$065C	inputs		Y	
	uses		X, Y, V, A, $7A	
	outputs		W	
				
	flag		effect	
	Z		set if V is zero	
	N		set if MSB of V is set	
				
	8 bit analogue:	4 char		LDA+
			standard	LDA (zp,X)
				
				
RLXY	[X,Y] --> W	Move word at address stored in X (low byte) and Y(high byte) into W		
$0663	inputs		X, Y	
	uses		X, Y, V, A, $7A	
	outputs		W	
				
	flag		effect	
	Z		set if W is zero	
	N		set if MSB of W is set	
				
	8 bit analogue:	4 char		LDAA
			standard	LDA addr
				
				
RMVW	V --> W       	Move V into W		
$0550	inputs		none	
	uses		X, Y, A, $7A	
	outputs		W	
				
	flag		effect	
	Z		set if V is zero	
	N		set if MSB of V is set	
				
	8 bit analogue:	4 char		TYAI
			standard	TYA
				
				
RMVX	V --> REGX	Move V into register pointed to by X		
$05FD	inputs		X	
	uses		X, Y, A, $7A	
	outputs		register pointed to by X	
				
	flag		effect	
	Z		set if W is zero	
	N		set if MSB of W is set	
				
	8 bit analogue:	4 char		STYZ
			standard	STY zp,X
				
				
RMWV	W --> V    	Move W into V		
$05F4	inputs		none	
	uses		X, Y, A, $7A	
	outputs		V	
				
	flag		effect	
	Z		set to 1	
	N		set to 0	
				
	8 bit analogue:	4 char		TAYI
			standard	TAY
				
				
RMWY	W --> REGY	Move W into register pointed to by Y		
$061C	inputs		Y	
	uses		X, Y, A, $7A	
	outputs		register pointed to by Y	
				
	flag		effect	
	Z		set to 1	
	N		set to 0	
				
	8 bit analogue:	4 char		STAZ
			standard	STA zp,X
				
				
RMXV	REGX --> V	Move contents of register pointed to by X into V		
$0605	inputs		X	
	uses		X, Y, A, $7A	
	outputs		V	
				
	flag		effect	
	Z		set if V is zero	
	N		set if MSB of V is set	
				
	8 bit analogue:	4 char		LDYZ
			standard	LDY zp,X
				
				
RMYW	REGY --> W	Move contents of register pointed to by Y into W		
$0623	inputs		Y	
	uses		X, Y, A, $7A	
	outputs		W	
				
	flag		effect	
	Z		set if W is zero	
	N		set if MSB of W is set	
				
	8 bit analogue:	4 char		LDAZ
			standard	LDA zp,X
				
				
RMZV	0 --> V   	Set V to zero		
$05EA	inputs		none	
	uses		X, Y, A, $7A	
	outputs		V	
				
	flag		effect	
	Z		set if V is zero	
	N		set if MSB of V is set	
				
	8 bit analogue:	4 char		LDY# 00
			standard	LDY #00
				
				
RMZW	0 --> W   	Set W to zero		
$053D	inputs		none	
	uses		X, Y, A, $7A	
	outputs		W	
				
	flag		effect	
	Z		set if W is zero	
	N		set if MSB of W is set	
				
	8 bit analogue:	4 char		LDA# 00
			standard	LDA #00
				
				
RPHV	V -->STACK	Push V to the stack		
$05E3	inputs		none	
	uses		X, Y, V, A, $7A	
	outputs		2 stack	
				
	flag		effect	
	Z		set if V = W	
	N		MSB of result of subtraction	
	C		set if overflow in result	
	V		set if sign bit is wrong	
				
	8 bit analogue:	4 char		PHYI
			standard	PHY
				
				
RPHW	W -->STACK	Push W to the stack		
$055C	inputs		none	
	uses		X, Y, W, A, $7A	
	outputs		2 stack	
				
	flag		effect	
	Z		set if W is zero	
	N		set if MSB of W is set	
				
	8 bit analogue:	4 char		PHAI
			standard	PHA
				
				
RPLV	V <--STACK	Pull V from the stack		
$05F0	inputs		2 stack	
	uses		X, Y, A, $7A	
	outputs		V	
				
	flag		effect	
	Z		set if W is zero	
	N		set if MSB of W is set	
				
	8 bit analogue:	4 char		PLYI
			standard	PLY
				
				
RPLW	W <--STACK	Pull W from the stack		
$054C	inputs		2 stack	
	uses		X, Y, A, $7A	
	outputs		W	
				
	flag		effect	
	Z		set if V is zero	
	N		set if MSB of V is set	
				
	8 bit analogue:	4 char		PLAI
			standard	PLA
				
				
RSUB	V - W --> W	Subtract W from V, store result in W		
$0577	inputs		none	
	uses		X, Y, A, V, W, $7A, $7B	
	outputs		W	
				
	flag		effect	
	Z		set if V is zero	
	N		set if MSB of V is set	
				
	8 bit analogue:	4 char		SBC#
			standard	SBC #
				
				
RSW-	W-->[[REGX]+Y]	Move W into word at ((address stored in 16 bit register pointed to by X) plus the Y offset)		
$0673	inputs		X, Y	
	uses		X, Y, V, A, $7A	
	outputs		contents of ((address stored in 16 bit register pointed to by X) plus the Y offset)	
				
	flag		effect	
	Z		set if W is zero	
	N		set if MSB of W is set	
				
	8 bit analogue:	4 char		STA-
			standard	STA (zp),Y
				
				
RSWP	V <--> W	Swap W and V		
$0543	inputs		none	
	uses		X, Y, 4 stack, A, $7A	
	outputs		V, W	
				
	flag		effect	
	Z		set if W is zero	
	N		set if MSB of W is set	
				
	8 bit analogue:	4 char		PHAI;PHYI;PLAI;PLYI
			standard	PHA;PHY;PLA;PLY
				
				
RSWV	W --> [V]	Move W into word at address stored in V		
$0684	inputs		none	
	uses		X, Y, V, A, $7A	
	outputs		address stored in V	
				
	flag		effect	
	Z		set if W is zero	
	N		set if MSB of W is set	
				
	8 bit analogue:	4 char		STA/
			standard	STA (zp)
				
				
RSWX	W --> [REGX]	Move W into word at (address stored in 16 bit register pointed to by X)		
$067C	inputs		X	
	uses		X, Y, V, A, $7A	
	outputs		contents of address in register pointed to by X	
				
	flag		effect	
	Z		set if W is zero	
	N		set if MSB of W is set	
				
	8 bit analogue:	4 char		STA+
			standard	STA (zp,X)
				
				
RSWY	W --> [REGY]	Move W into word at (address stored in 16 bit register pointed to by Y)		
$067A	inputs		Y	
	uses		X, Y, V, A, $7A	
	outputs		contents of address in register pointed to by Y	
				
	flag		effect	
	Z		set if W is zero	
	N		set if MSB of W is set	
				
	8 bit analogue:	4 char		STA+
			standard	STA (zp,X)
				
				
RSXY	W --> [X,Y]	Move W into word at address stored in X (low byte) and Y(high byte)		
$0681	inputs		X, Y	
	uses		X, Y, V, A, $7A	
	outputs		contents of address pointed to by X, Y	
				
	flag		effect	
	Z		set if W is zero	
	N		set if MSB of W is set	
				
	8 bit analogue:	4 char		STAA
			standard	STA addr
				
				
RV--	V – 1 --> V	Decrement V		
$05D7	inputs		none	
	uses		X, Y, A, W, $7A	
	outputs		V	
				
	flag		effect	
	Z		set if W is zero	
	N		set if MSB of W is set	
				
	8 bit analogue:	4 char		DEYI
			standard	DEY
				
				
RV++	V + 1 --> V	Increment V		
$05CF	inputs		none	
	uses		X, Y, A, W, $7A	
	outputs		V	
				
	flag		effect	
	Z		set if W is zero	
	N		set if MSB of W is set	
	 		 	
	8 bit analogue:	4 char		INYI
			standard	INY
				
				
RW--	W-1 --> W	Decrement W		
$056B	inputs		none	
	uses		X, Y, A, W, $7A	
	outputs		W	
				
	flag		effect	
	Z		set if W is zero	
	N		set if MSB of W is set	
	 		 	
	8 bit analogue:	4 char		DECI
			standard	DEC A
				
				
RW++	W+1 --> W	Increment W		
$0563	inputs		none	
	uses		X, Y, A, W, $7A	
	outputs		W	
				
	flag		effect	
	Z		set if W is zero	
	N		set if MSB of W is set	
	C		old MSB of W	
				
	8 bit analogue:	4 char		INCI
			standard	INC A
				
				
RWR<	ROTATE W LEFT	Rotate W left one bit		
$063B	inputs		none	
	uses		X, Y, A, W, $7A, $7B	
	outputs		W	
				
	flag		effect	
	Z		set if W is zero	
	N		set if MSB of W is set	
	C		old LSB of W	
				
	8 bit analogue:	4 char		ROLI
			standard	ROL A
				
				
RWR>	ROTATE W RIGHT	Rotate W right one bit		
$0649	inputs		none	
	uses		X, Y, A, W, $7A, $7B	
	outputs		W	
				
	flag		effect	
	Z		set if W is zero	
	N		set if MSB of W is set	
	 		 	
	8 bit analogue:	4 char		RORI
			standard	ROR A
				
				
RWS<	SHIFT W LEFT	Shift W left one bit		
$0631	inputs		none	
	uses		X, Y, A, W, $7A, $7B	
	outputs		W	
				
	flag		effect	
	Z		set if W is zero	
	N		set if MSB of W is set	
				
	8 bit analogue:	4 char		ASLI
			standard	ASL A
				
				
RWS>	SHIFT W RIGHT	Shift W right one bit		
$0636	inputs		none	
	uses		X, Y, A, W, $7A, $7B	
	outputs		W	
				
	flag		effect	
	Z		set if W is zero	
	N		set if MSB of W is set	
				
	8 bit analogue:	4 char		LSRI
			standard	LSR A





-----------------------------------

-30-


                                                                                                                                                                                     You're still here?  It's over.  Go home.  Go.