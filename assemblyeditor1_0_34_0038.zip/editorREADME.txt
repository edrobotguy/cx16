Commander X-16 Assembly Language Editor 
v1.0.34.0038 
by Ed Minchau, spider_boris@yahoo.com
2020

-----------------------------------


0) Introduction

The CX16 Assembly Language Editor was made to allow easy development of assembly language programs on the Commander X16.
The editor is meant to be as small as possible, while still having lots of functionality.  Users can write their code
directly in the CX16 environment, test it from within the editor, and easily save their code to disk.  Addresses can be
replaced with labels, and code can be commented.

The editor is mostly located in paged RAM from $A000 to $BFFE.  There is a short bootstrap program located from $0801 to
$0BFF.  The bootstrap program loads the editor and label/comment files and runs the editor, but it also contains several
short subroutines that end users might find useful in their own programs.  This leaves the RAM from $0C00 to $9EFF 
available for the user's own assembly language program, 36.75 kilobytes of contiguous space.

Of the memory used in paged RAM, only $A000 to $AFFF is the editor itself.  The memory at $B000 to $B5FF is set aside for
labels, and $B600 to $BFFE is set aside for comments.

The editor sets the screen to 40x30 character display mode, because my eyes are getting old and I need new glasses.


-----------------------------------


1) Contents

	0. Introduction
	1. Contents
	2. Version and License
	3. Revision History
	4. Getting Started
		4.1 Demo video
	5. Display Modes
		5.0 Status bar
		5.1 Assembly code, branch to address
		5.2 Assembly code, branch relative
		5.3 Data mode, block byte
		5.4 Data mode, single byte
		5.5 Character mode
	6. function and arrow keys
	7. assembly language notation
	8. special functions
		8.1 GOTO, EXEC, SAVE, QUIT
		8.2 COMM, DCOM, SLBL, DLBL
		8.3 CHAR, DATA, COPY, MOVE
		8.4 Branch to address pseudocommands
	9. Labels
		9.1 setting and deleting labels
		9.2 Kernal labels
		9.3 VERA labels
		9.4 special labels
	10. Comments
	11. Useful subroutines in BOOTSTRAP.PRG
	12. Future work

	Appendix A: table of 65c02 commands sorted by opcode
	Appendix B: alphabetical list of 65c02 commands  


-----------------------------------


2) Version and License

Major version: 1
Minor version: 0
emulator version: 34
build number: 0038

IMPORTANT: this is *only for version 34* of the emulator.  The guys making the emulator have gone so fast, they've made five
breaking updates to the emulator since I started writing this editor.  The last update was only a couple of weeks ago, as I was
debugging, and what with Christmas and New Year's and all I haven't had a chance to update to version 35 yet.


The license of this software is pretty straightforward: use any of it that you like in your own software, just leave
the following 80 byte string (currently stored at $0A00-$0A4F) somewhere in the code:

YOU CAN USE ANY OF THIS CODE,JUST LEAVE
THIS MESSAGE SOMEWHERE ED MINCHAU 2019

Since the license is stored in memory within the bootstrap program, which will itself become part of user programs, you
don't actually need to do anything.


-----------------------------------


3) Revision History

	v1.0.34.0038: first release

-----------------------------------


4) Getting Started

If you're reading this README file, then you've already downloaded the code from GitHub.  Good.  Just make sure you've
extracted everything from the zip file (BOOTSTRAP.PRG, DEFAULT.LBL, MLEDITOR.PRG, and editorREADME.TXT) into your
directory containing the emulator version 34.  To start, launch the emulator, and then type:

LOAD"BOOTSTRAP.PRG"
RUN

You will be shown a status bar and PRESS ANY KEY TO CONTINUE.  Click a key and the editor starts in mode 1 at address $0C00,
the first available address for user programs.


4.1) Demo Video

A demonstration video, showing how to create a Hello World program using the editor, is available on YouTube at
https://youtu.be/8Owsad07Cdk


-----------------------------------


5) Display Modes

There are five display modes available in the editor.  Use the F4 key to cycle between the display modes.

To keep the parsing code short, the keypresses that are accepted by the editor are limited.  When entering a command, only
letters, numbers, and the symbols + - # and / are allowed.  When entering two hex digits, only the keys 0 to 9 and A to F
are accepted.  When moving the cursor, only arrow keys, F4, and letters are allowed.  When entering a filename, only letters,
numbers, a slash, a period, or a Return are allowed.

In all cases, whether entering commands or parameters or other data, backspace is allowed, to a point.  If you backspace to
the beginning, then whatever you were entering aborts and goes back to the editing mode, as if nothing ever happened and let
us never speak of this thing again.  For instance, if you start entering a command and change your mind halfway through entering
a parameter, backspacing to the beginning of that parameter just aborts the command entry, the command isn't stored at that
location, and the display reverts to as it was before you started typing the command.


5.0) mode 0: Status bar

Mode 0 isn't really an editing mode.  It simply displays a truncated status bar (no program counter), and 

PRESS ANY KEY TO CONTINUE

As soon as a key is pressed, it clears the screen and switches to mode 1.  Peri Fractic, can I get a keyboard with one
of the X16 keys replaced with a key marked ANY, please?  Then I could say, there it is.


5.1) mode 1: Assembly code, branch to address

The first mode shows the assembly language code in the notation (see section 7) unique to this editor.  This mode also
shows all branches as being to an absolute address rather than to a relative address.  The branch commands themselves are 
displayed differently in this mode e.g. BNEA instead of BNE# (see section 8.4).  In either mode 1 or mode 2 you can enter
branches as either to an absolute address or a relative address, but in this mode all branches are displayed with absolute
addresses.

Each line on this screen corresponds to one command.  It shows the address, the command, any parameters, the list of 1-3
bytes representing that line of code, and any comments.  If the address at the top of the screen happens to be a parameter
rather than a command, the editor will still try to display it as a command.  As a result the top few lines of the screen 
may be muddled.  Moving the cursor up to the top of the screen, and then up one or two more times, will eventually bring
an actual command to the top of the screen.

When pressing F4 to switch to mode 2, the cursor does not change position and the address at the top of the screen remains
the same.


5.2) mode 2: Assembly code, branch relative

The second mode differs from the first mode only in the way it displays branches, always showing branches to relative
addresses.  You can still enter branches to absolute addresses in this mode, but they will immediately be displayed as
the correct relative addresses.

When pressing F4 to switch to mode 3, the address currently pointed to by the cursor becomes the address at the top left
corner of the screen, and the cursor moves to that location.


5.3) mode 3: Data mode, block byte

This third mode shows 30 rows of 8 bytes per row, with each of the 8 bytes first displayed as hex digits, and then displayed
as 8 characters.  If a byte is not a printable character then it is displayed as a default checkerboard character.

The address at the left side of the screen is the address of the first of the eight bytes on that row. Data can be entered
wherever the * cursor is, as hex digits.  In this mode, you can use the left and right arrows as well as the up and down arrows
to move the cursor around.

When switching to mode 4 by pressing F4, the address currently pointed to by the cursor becomes the address at the top of
the screen, and the cursor moves to the top.


5.4) mode 4: Data mode, single byte

The fourth mode shows one byte per row, first as two hex digits and then the individual bits, with an empty circle representing
a zero and a filled circle representing a one.  Data can be entered as hex digits wherever the * cursor is.

When switching to mode 5 by pressing F4, the address at the top of the screen remains the same and the cursor points to the same
address as in mode 4.


5.5) mode 5: Character mode

The fifth display mode shows one byte per row again, this time represented as characters.  The hex digits of the byte are also
shown.  In this mode, characters can be entered wherever the * cursor is.  Certain keys will not be entered as characters in
this mode: the up and down arrow keys just move the cursor up and down, and F4 will switch the editor back to mode 1.  However,
all other keys on the keyboard can be entered as characters this way.  A moose once bit my sister.

If a byte is not a printable character, then it is shown as a default checkerboard character.

When switching back to mode 1 by pressing F4, the address currently pointed to by the cursor becomes the address at the top of
the screen, and the cursor moves to the top.


-----------------------------------


6) Function and arrow keys

While I was developing this editor, the arrow keys died on my old computer, and the emulator doesn't recognize the number pad.
Rather than wait for a new computer, I echoed the arrow keys to some of the function keys.  So, in mode 3, F1 and F7 do the same
things as the left and right arrow keys.  And, in all five editor modes, the F3 key does the same thing as up arrow, and the F5
key does the same as the down arrow.

This will probably change in the next version of the editor, as I now have a new computer and don't need that kludge anymore.

In all editor modes, F4 switches to the next display mode, and the up and down arrow keys move the cursor.  The left and right
arrow keys only work in mode 3.


-----------------------------------


7) assembly language notation

In an effort to keep the editor as small as possible, I had to make certain tradeoffs.  The most important tradeoff was changing
the notation of the assembly language code from a standard notation to one where each command is represented by a unique four-
character code.  For most commands, the first three characters are identical to the standard notation, and the fourth character
represents the addressing mode.  It might raise the hackles of experienced 6502 programmers, but it doesn't take long to get used
to the syntax, and once you're used to it it's actually easier to read than the standard notation; one's eyes move straight down
the screen instead of bouncing left and right.

Let's take LDA as an example.  This command loads the accumulator.  There are nine different LDA commands, and in standard 65c02
editors a parser would have to figure out which of the nine LDA commands was desired by looking at the syntax of the parameters
which followed.  In this editor however, each of the nine LDA commands has a unique fourth character indicating addressing mode, 
eliminating much of the code needed to parse user input.

Addressing mode		4-character code	standard notation
immediate		LDA#			LDA #
zero page		LDA0			LDA zp
zero page,X		LDAZ			LDA zp,X
absolute		LDAA			LDA addr
absolute,X		LDAX			LDA addr,X
absolute,Y		LDAY			LDA addr,Y
(indirect,X)		LDA+			LDA (zp,X)
(indirect),Y		LDA-			LDA (zp),Y
(indirect)		LDA/			LDA (zp)


There are a couple of commands (LDX and STX) that have a zero page,Y addressing mode.  These are represented by the four-
character codes LDXZ and STXZ.

There is also an implied addressing mode (e.g. INXI, TAYI, PHYI, RTSI).  There are a few of the Implied mode commands
represented with other characters than I as the fourth character, mostly having to do with flags or convenience:
e.g. CLCF, SECF, CLID, SEID, CLDM, SEDM, NOPE, BRK0, WAIT, STOP

The new 65c02 commands RMB0 through RMB7 and SMB0 through SMB7 are the same as the standard notation, since they are already
unique four-character codes.

The branching commands are all in a relative addressing mode.  For BBR0 through BBR7 and BBS0 through BBS7, the commands are
identical to standard 65c02 notation, since they're already unique four-character codes.  The other branch operations use the 
symbol # to represent relative addressing mode, with one exception: the new 65c02 unconditional branch command has the code BRAN.

Relative branches are easy for the computer to understand, but a little harder for programmers.  The editor has the ability to
input branches to an absolute address, which it then converts for you to a relative address.  These pseudo-commands are:
BPLA, BMIA, BVCA, BVSA, BRAA (the new unconditional branch, but to an address), BCCA, BCSA, BNEA, and BEQA. (see section 8.4)

A few commands - ASL, LSR, ROL, ROR, DEC, and INC - have both an absolute addressing mode and an Accumulator mode.  They can't
both use the letter A as the fourth character.  For these six commands the Accumulator mode is treated as Implied mode.


command 	Addressing mode		standard notation	4-character code
					
ASL     	Accumulator		ASL A   		ASLI
ASL     	absolute		ASL addr		ASLA
LSR     	Accumulator		LSR A   		LSRI
LSR     	absolute		LSR addr		LSRA
ROL     	Accumulator		ROL A   		ROLI
ROL     	absolute		ROL addr		ROLA
ROR     	Accumulator		ROR A   		RORI
ROR     	absolute		ROR addr		RORA
DEC     	Accumulator		DEC A   		DECI
DEC     	absolute		DEC addr		DECA
INC     	Accumulator		INC A   		INCI
INC     	absolute		INC addr		INCA


The 6502 had a number of unused / undocumented opcodes, some of which actually did something useful and some which wreaked
havoc.  This has been changed for the 65c02, where all unused opcodes are one, two, or three byte NOP commands.  These are
represented in the editor by the codes NOP1, NOP2, and NOP3, respectively.  Mynd you, moose bites Kan be pretti nasti.

The full list of commands is given in both Appendices A and B.  Appendix A lists the commands in order of opcode, with the
4-character codes assigned to each command, the standard notation, number of bytes, and number of cycles.  Appendix B lists
the commands in alphabetical order, including the addressing mode, opcode, 4-character code, standard notation, number of 
bytes, number of cycles, and the flags affected by each command. 


-----------------------------------


8) Special Functions

Changing the notation to four character codes gave me a 1.25 kb lookup table (256 commands, four bytes for characters and a
fifth byte for number of bytes in command).  This allowed me to sneak 12 functions and 9 pseudocommands into the lookup table
at unused opcodes (NOP1 and NOP2).  These functions and extra commands are listed in this section.

These functions and pseudocommands only work in modes 1 and 2.


8.1) GOTO, EXEC, SAVE, QUIT

These are the four most important functions in the editor.


8.1.1) GOTO

GOTO allows you to go to any address.  Just type GOTO and the address or label.  That's it.


8.1.2) EXEC

EXEC turns over control of the computer from the editor to the code located at the address entered.  Just type EXEC and the
address or label of the address to be executed.  If your code ends in an RTSI command, then when your code is finished control
will return to the editor in mode 0, displaying the status bar before returning you to mode 1.  This is very useful for testing
sections of code or even an entire program.


8.1.3) SAVE

SAVE lets you save your work.  To save a file in assembly language, you need to specify logical file number, device number, and
secondary address; for now, this is set to the main directory of the X-16 emulator.  Then you need to set the file name, the start
address of the file, and the location of the last byte in the file plus one.

The SAVE function tries to set the start and end+1 addresses by looking for the special labels FSTR and FEND (see section 9.4);
if those labels are not found, then it sets default start ($0801) and end+1 ($0D00) addresses.  These can by accepted by the user
by hitting Return, or overridden by typing another address or label.  The function then prompts for a filename, up to 32 characters
long.  The only characters allowed are letters, numbers, the period, the slash, and Return.

Once the file start, file end+1, and filename are set, the function prompts ARE YOU SURE?(Y/N) and waits for either a Y or N to
be pressed.  

If Y, the function creates another filename by searching backwards in the user's filename for the last period, placing the file
extension LBL afterwards.  If the filename is so long that the last period is the 29th or later character, then the label
filename is the first 28 characters of the user's filename followed by .LBL ; if there is no period in the user's filename, then
.LBL is appended to the user's filename at the end or at the 29th character, whichever is less.

This label filename is used to create a companion label file to the user's program.  That way each of the user's programs has a
unique label file, which is loaded whenever the user's program is loaded for editing.

Then the function saves both the user's program and the corresponding label file.

It's important to note that the BOOTSTRAP.PRG file starts at $0801, and that is also the default value of FSTR.  The only BASIC
command in this file is

1 SYS 2061

which corresponds to location $080D.  The values at $080D, $080E and $080F are all $EA, No Operation commands.  While you are
still editing your assembly language program you can keep these as NOPEs, but when you want your program to run upon loading
rather than the editor, just change these three bytes to a JMPA to the start of your program.  If you want to get back into
the editor after having done that and saved your program, just load your program and type

SYS 2064

This will bypass those three bytes and go into the routine that loads and launches the editor and loads the labels and comments
for the user's program.


8.1.4) QUIT

QUIT takes no parameters.  It triggers an ARE YOU SURE?(Y/N) prompt, which waits for Y or N to be pressed.  If Y, the screen 
returns to the normal 80 column mode and is cleared and control is returned to BASIC.  If N, it returns back to mode 1 or 2.



8.2) COMM, DCOM, SLBL, DLBL

These four commands set and delete comments and labels, respectively.  Comments are covered in more detail in section 10 below,
and labels are covered in section 9.


8.3) CHAR, DATA, COPY, MOVE

These last four are the "convenience" functions.  Having them around just makes life easier.


8.3.1) CHAR and DATA

When editing in mode 1 or mode 2, sometimes you will want to enter either raw data or to enter data as characters.  You can hit
F4 a few times to switch to mode 4 or mode 5, or you can go straight to mode 4 by typing

DATA

or straight to mode 5 by typing 

CHAR

It might seem like these are redundant commands, particularly since it could be fewer keypresses to just use F4 a few times, but
they actually come in quite handy for a psychological reason: your train of thought isn't interrupted by counting keypresses.  In
either case, the address pointed to by the cursor in mode 1 or 2 becomes the address at the top of the screen, and the cursor
moves to the top.


8.3.2) COPY and MOVE

The COPY and MOVE functions are closely related.  For each of these commands, there are three prompts: FROM, TO, and #BYTES.
Unsurprisingly, these are the source address, destination address, and number of bytes to be moved or copied.  Enter a number from
01 to FF for #BYTES; entering 00 aborts the copy or move.

In both cases, if the data is being copied or moved from a lower address to a higher address, it starts at the last byte and works
its way to the first, and if going from higher address to lower address it does so from first to last.  This avoids the possibility
of accidentally overwriting data before it can be copied or moved.

In both cases if there is a label or comment at an address in the destination group of bytes, that label or comment is deleted.

The difference between COPY and MOVE is that COPY does not affect the source data.  For MOVE, if a label or comment is encountered
in the source data, that label or comment is also moved to the destination.  And once data is moved to the destination, the source
byte is replaced by a NOPE.

Note that when you MOVE a byte from an address associated with a label, the label itself moves but the data does not change.  Any
JMPs or JSRs to that label must be changed manually.



8.4) Branch to address pseudocommands

All branch commands on the 65c02 are to relative addresses.  The parameter is the relative address in two's complement notation,
so the byte represents an offset in the range -128 to +127.  That offset is calculated starting from the address of the command
following the branch command.

Figuring out the relative address can be done by simple counting if it's within a short range, or by subtracting the destination
address from the address of the command following the branch.

However, we're people, and want to do things the easy way.  For each of the following branch commands

BPL#, BMI#, BVC#, BVS#, BRAN, BCC#, BCS#, BNE#, BEQ#

There is a corresponding pseudocommand 

BPLA, BMIA, BVCA, BVSA, BRAA, BCCA, BCSA, BNEA, BEQA

These pseudocommands take an address or a label as a parameter, and convert it to the relative address for you.  In memory, the
regular branch command corresponding to the pseudocommand is stored, along with the correct relative address.

In editor mode 1, all these branches are displayed as if they were the pseudocommands, showing branches to an address or label.
In mode 2 however they are shown as the regular branch commands and relative addresses, exactly as they are stored in memory.
In either mode 1 or mode 2 you can type in either the regular branch command or the pseudocommand, the editor doesn't mind.



-----------------------------------


9) Labels

When writing an assembly language program, you're usually not writing one huge program but rather hundreds of subroutines.
Many of those subroutines will have lots of JSRs and JMPs to these various subroutines.  Well, one hex address pretty much 
looks like any other, and it's easy to make mistakes jumping to the wrong address.

To make life easier for programmers, the editor allows you to set a label on an address.  The programmer can then use the label
anywhere one otherwise would have used the address.  This makes the program much more readable, as a series of JSRs is not to
obscure addresses but to slightly-less-obscure labels.

You can have up to 255 labels in your program.  However, some labels are already in use, for things like Kernal jump vectors and
VERA registers and a few other special labels.  You've got about 200 labels available unless you delete some of the labels which
are already in use but which you don't need.


9.1) setting and deleting labels

A label is a four-character code starting with a letter, using only letters, numbers, and the symbols # + - /

To set a label (mode 1 or mode 2 only), move the cursor to the address you want to label and type

SLBL

Then enter the four character code you want for your label.

At least one of the four characters must not be hexadecimal; there has to be a letter higher than F or a symbol in the label.
Using BEEF as a label would be bad, because the parser wouldn't know if it referred to the hexadecimal address $BEEF or to the
label of the same name.  So, attempting to use a hex address as a label is not allowed by the editor.

Also, a label cannot duplicate an existing label; two addresses can't be named the same thing.  Attempting to set a label that
is already in use would be bad.  Try to imagine all life as you know it stopping instantaneously and every molecule in your body
exploding at the speed of light.  So, the editor won't allow it.

If the label file is full (number of labels = 255) then the editor won't allow SLBL to work at all.

If you want to change an existing label, just GOTO that label and type SLBL and the new label.  The new label is just stored
over the old one.

To delete a label, goto the label you want to delete and type

DLBL

and just like that, it's gone.  If you try do DLBL on an address that doesn't have a label, nothing happens.


9.2) Kernal labels

There are 36 labels that correspond to the Kernal jump vectors.  The source for these addresses and subroutine names was the
Commodore VIC-20 Programmer's Reference Guide (pages 182-210, highly recommended):

http://www.classiccmp.org/cini/pdf/Commodore/VIC-20%20Programmer%27s%20Reference%20Guide.pdf

Only those Kernal addresses listed in that book are converted to labels here.  This may be updated in future versions of the
editor, depending on what changes occur to the emulator.  The labels, their addresses, and corresponding Kernal subroutine names
are as follows:

ACPT	$FFA5	ACPTR
CHKI	$FFC6	CHKIN
CHKO	$FFC9	CHKOUT
CHRI	$FFCF	CHRIN
CHRO	$FFD2	CHROUT
COUT	$FFA8	CIOUT
CLAL	$FFE7	CLALL
CLOS	$FFC3	CLOSE
CLRC	$FFCC	CLRCHN
GETI	$FFE4	GETIN
IOBA	$FFF3	IOBASE
LSTN	$FFB1	LISTEN
LOAD	$FFD5	LOAD
MEMB	$FF9C	MEMBOT
MEMT	$FF99	MEMTOP
OPEN	$FFC0	OPEN
PLOT	$FFF0	PLOT
RDTI	$FFDE	RDTIM
RDST	$FFB7	READST
RSTO	$FF8A	RESTOR
SAVE	$FFD8	SAVE
SCNK	$FF9F	SCNKEY
SCRN	$FFED	SCREEN
SCND	$FF93	SECOND
SLFS	$FFBA	SETLFS
SMSG	$FF90	SETMSG
SNAM	$FFBD	SETNAM
STIM	$FFDB	SETTIM
STMO	$FFA2	SETTMO
STOP	$FFE1	STOP
TALK	$FFB4	TALK
TKSA	$FF96	TKSA
UDTI	$FFEA	UDTIM
ULSN	$FFAE	UNLSN
UTLK	$FFAB	UNTLK
VCTR	$FF84	VECTOR


9.3) VERA labels

The VERA video card has its own set of 8 labels.  Here's a list of those labels, their addresses, and VERA names:

VELO	$9F20	VERA_ADDR_LO
VEMD	$9F21	VERA_ADDR_MID
VEHI	$9F22	VERA_ADDR_HI
VDT0	$9F23	VERA_DATA0
VDT1	$9F24	VERA_DATA1
VCON	$9F25	VERA_CTRL
VIEN	$9F26	VERA_IEN
VISR	$9F27	VERA_ISR


9.4) special labels

There are two special labels related to saving files with the editor, FSTR and FEND.  By default, FSTR is set at $0801; there
is no FEND set by default.  FSTR points to the start of the file, in this case the start of the BASIC routine that kickstarts
the editor or eventually the user's program.  FEND is not strictly required, but if it is set the SAVE routine will assume that
it points to the end of the user's program plus one byte.  It is convenient to set this label before saving the file, so you
don't have to remember that address.


There is a group of seven labels that correspond to useful subroutines in the bootstrap code:  

S110, PSTR, PANY, GKDB, ISUB, IADD, SCLR

These subroutines are discussed in section 11 below.


There is one label set by default that is within the editor: LLBL.  If you load and run BOOTSTRAP.PRG, and then before setting
or deleting any comments or labels you type

EXEC LLBL

then all of the labels and comments I put into the editor itself become visible.  See for yourself the kludgy mess of 
spaghetti code I made of this editor.

After executing LLBL, one of the labels that becomes visible is LISC, and by executing that code EXEC LISC
you will see the software license.

If you want to get rid of the editor labels and make it return to the default, then type

EXEC RLBL

and you can make it all go away, back the way it was before.

If you execute LLBL after you have already set or deleted some labels or comments, then you will have overwritten some of the
editor's own (hidden) labels or comments.


-----------------------------------


10) Comments

There is space for 127 comments available for each program you write with this editor.  The bootstrap program starts with a
set of 5 default comments for some of the short useful subroutines available in $0801 - $0BFF.

Because there are so few comments available, and because each is limited to a maximum of 16 characters, your comments need
to be useful, concise, and sparse.  Comment only what you have to, and cram as much information into your comment as you can.
You're limited to using only letters, numbers, spaces, and the symbols + - # and / so get creative.

Avoid useless comments; a comment like TRANSFER Y TO A is useless if the command it refers to is TYAI.  We can see that it is
transferring Y to A.  We're smart, not like everybody says.

A comment like JOY UP HANDLE is far more useful.  Be like JOY UP HANDLE.

To add a comment to an address, enter the command

COMM

The editor changes it to read COMMENT: and puts a semicolon and a cursor where you type your comment, to a maximum of 16
characters.  If a comment already existed at that address, it gets wiped out and replaced with the new comment.  If your
comment is less than 16 characters you can end it by pressing Return.  If the number of comments is already at the limit,
then COMM does nothing.

To delete a comment at an address, enter the command

DCOM

and the comment will be deleted.  If there was no comment at that address then nothing happens.


-----------------------------------


11) Useful subroutines in BOOTSTRAP.PRG

There are a number of small subroutines in the bootstrap program which you may find useful.

S110 ($0867)	- sets the logical and first address to 1, secondary address to zero.
		- useful when loading from disk.  Calling this saves you four bytes.

PSTR ($08A9)	- prints a string of length A pointed to by X (low byte) and Y (high byte)

PANY ($099A)	- prints PRESS ANY KEY TO CONTINUE and waits for a keypress

GKDB ($09A1)	- Get Key with DeBounce
		- waits until no key is being pressed, then waits for a keypress and returns PETSCII result in A
		- result is also returned in address $0071

ISUB ($09B2)	- 16 bit integer subtraction
		- zero page 7C & 7D are lo/hi of one 16 bit value, 7E & 7F are the lo/hi of another 16 bit value
		- ISUB changes 7C & 7D to its two's complement value and then runs IADD, subtracting 7C/7D from 7E/7F.

IADD ($09C8)	- 16 bit integer addition
		- zero page 7C & 7D are added to zero page 7E & 7F, result stored in 7E & 7F.

SCLR ($0A60)	- clears the screen


-----------------------------------


12) Future Work

Now that I've got this working, it's full of kludges.  I'm going to refactor the whole thing.  I'll also eliminate the kludge
I put in to echo the arrow keys to F1, F3, F5, and F7.

The editor currently works for version 34 of the emulator, but the newest version of the emulator is v35.  So, I'll need to make
a couple of changes to get it working for that version.  And I'll try to keep up with changes to the emulator as they happen.

I also want to expand the branch-to-address pseudocommands to the commands BBR0-BBR7 and BBS0-BBS7.  This will probably mean
displaying comments differently because I need the space where the semicolon goes.  Comments will probably have their foreground
and background colors reversed.

There is no SD card support and no way of viewing the file directory.  I might add that.

Later I may write another version of the editor that resides completely in low program memory, with the labels and comments loaded
into paged memory.  That would allow maybe 510 labels and 256 comments, at the cost of 5kb of low memory taken up by the editor.
Or maybe put the whole thing in low memory to allow editing of paged memory.  I haven't decided yet.


-----------------------------------


Appendix A:  table of 65c02 commands

The following table lists the 4-character codes assigned to each command, along with the standard notation, # of bytes,
and # of cycles.  The table is sorted by opcode and tab-separated, so you can load it directly into your favorite spreadsheet.

More information available at https://www.westerndesigncenter.com/wdc/documentation/w65c02s.pdf
Detailed information about the new 65c02 commands is available at http://6502.org/tutorials/65c02opcodes.html
Lots more tutorials on assembly language programming are available at http://6502.org/tutorials/

legend:
	opcode : 4 character code			cycle notes:	a: +1 if crossing page boundary
	standard notation               				b: +1 if D flag is set
	#bytes, #cycles(notes)          				c: +1 if branch taken


00 : BRK0	01 : ORA+	02 : NOP2	03 : NOP1	04 : TSB0	05 : ORA0	06 : ASL0	07 : RMB0	08 : PHPI	09 : ORA#	0A : ASLI	0B : NOP1	0C : TSBA	0D : ORAA	0E : ASLA	0F : BBR0
BRK imp  	ORA (zp,X)	---     	---     	TSB zp  	ORA zp  	ASL zp  	RMB0 zp 	PHP imp 	ORA #   	ASL Acc 	---     	TSB abs 	ORA abs 	ASL abs 	BBR0 zp,rel
1byt, 7cyc	2byt, 2cyc	2byt, 2cyc	1byt, 1cyc	2byt, 5cyc	2byt, 3cyc	2byt, 5cyc	2byt, 5cyc	1byt, 3cyc	2byt, 2cyc	1byt, 2cyc	1byt, 1cyc	3byt, 6cyc	3byt, 4cyc	3byt, 6cyc	3byt, 5cyc
															
10 : BPL#	11 : ORA-	12 : ORA/	13 : NOP1	14 : TRB0	15 : ORAZ	16 : ASLZ	17 : RMB1	18 : CLCF	19 : ORAY	1A : INCI	1B : NOP1	1C : TRBA	1D : ORAX	1E : ASLX	1F : BBR1
BPL rel 	ORA (zp),Y	ORA (zp)	---     	TRB zp  	ORA zp,X	ASL zp,X	RMB1 zp 	CLC imp 	ORA abs,Y	INC Acc 	---     	TRB abs 	ORA abs,X	ASL abs,X	BBR1 zp,rel
2byt, 2cyc(ac)	2byt, 5cyc(a)	2byt, 5cyc	1byt, 1cyc	2byt, 5cyc	2byt, 4cyc	2byt, 6cyc	2byt, 5cyc	1byt, 2cyc	3byt, 4cyc(a)	1byt, 2cyc	1byt, 1cyc	3byt, 6cyc	3byt, 4cyc(a)	3byt, 6cyc(a)	3byt, 5cyc
															
20 : JSRA	21 : AND+	22 : NOP2	23 : NOP1	24 : BIT0	25 : AND0	26 : ROL0	27 : RMB2	28 : PLPI	29 : AND#	2A : ROLI	2B : NOP1	2C : BITA	2D : ANDA	2E : ROLA	2F : BBR2
JSR abs 	AND (zp,X)	---     	---     	BIT zp  	AND zp  	ROL zp  	RMB2 zp 	PLP imp 	AND #   	ROL Acc 	---     	BIT abs 	AND abs 	ROL abs 	BBR2 zp,rel
3byt, 6cyc	2byt, 6cyc	2byt, 2cyc	1byt, 1cyc	2byt, 3cyc	2byt, 3cyc	2byt, 5cyc	2byt, 5cyc	1byt, 4cyc	2byt, 2cyc	1byt, 2cyc	1byt, 1cyc	3byt, 4cyc	3byt, 4cyc	3byt, 6cyc	3byt, 5cyc
															
30 : BMI#	31 : AND-	32 : AND/	33 : NOP1	34 : BITZ	35 : ANDZ	36 : ROLZ	37 : RMB3	38 : SECF	39 : ANDY	3A : DECI	3B : NOP1	3C : BITX	3D : ANDX	3E : ROLX	3F : BBR3
BMI rel 	AND (zp),Y	AND (zp)	---     	BIT zp,X	AND zp,X	ROL zp,X	RMB3 zp 	SEC imp 	AND abs,Y	DEC Acc 	---     	BIT abs,X	AND abs,X	ROL abs,X	BBR3 zp,rel
2byt, 2cyc(ac)	2byt, 5cyc(a)	2byt, 5cyc	1byt, 1cyc	2byt, 4cyc	2byt, 4cyc	2byt, 6cyc	2byt, 5cyc	1byt, 2cyc	3byt, 4cyc(a)	1byt, 2cyc	1byt, 1cyc	3byt, 4cyc(a)	3byt, 4cyc(a)	3byt, 6cyc(a)	3byt, 5cyc
															
40 : RTII	41 : EOR+	42 : NOP2	43 : NOP1	44 : NOP2	45 : EOR0	46 : LSR0	47 : RMB4	48 : PHAI	49 : EOR#	4A : LSRI	4B : NOP1	4C : JMPA	4D : EORA	4E : LSRA	4F : BBR4
RTI imp 	EOR (zp,X)	---     	---     	---     	EOR zp  	LSR zp  	RMB4 zp 	PHA imp 	EOR #   	LSR Acc 	---     	JMP abs 	EOR abs 	LSR abs 	BBR4 zp,rel
1byt, 6cyc	2byt, 6cyc	2byt, 2cyc	1byt, 1cyc	2byt, 3cyc	2byt, 3cyc	2byt, 5cyc	2byt, 5cyc	1byt, 3cyc	2byt, 2cyc	1byt, 2cyc	1byt, 1cyc	3byt, 3cyc	3byt, 4cyc	3byt, 6cyc	3byt, 5cyc
															
50 : BVC#	51 : EOR-	52 : EOR/	53 : NOP1	54 : NOP2	55 : EORZ	56 : LSRZ	57 : RMB5	58 : CLID	59 : EORY	5A : PHYI	5B : NOP1	5C : NOP3	5D : EORX	5E : LSRX	5F : BBR5
BVC rel 	EOR (zp),Y	EOR (zp)	---     	---     	EOR zp,X	LSR zp,X	RMB5 zp 	CLI imp 	EOR abs,Y	PHY imp 	---     	---     	EOR abs,X	LSR abs,X	BBR5 zp,rel
2byt, 2cyc(ac)	2byt, 5cyc(a)	2byt, 5cyc	1byt, 1cyc	2byt, 4cyc	2byt, 4cyc	2byt, 6cyc	2byt, 5cyc	1byt, 2cyc	3byt, 4cyc(a)	1byt, 3cyc	1byt, 1cyc	3byt, 8cyc	3byt, 4cyc(a)	3byt, 6cyc(a)	3byt, 5cyc
															
60 : RTSI	61 : ADC+	62 : NOP2	63 : NOP1	64 : STZ0	65 : ADC0	66 : ROR0	67 : RMB6	68 : PLAI	69 : ADC#	6A : RORI	6B : NOP1	6C : JMPI	6D : ADCA	6E : RORA	6F : BBR6
RTS imp 	ADC (zp,X)	---     	---     	STZ zp  	ADC zp  	ROR zp  	RMB6 zp 	PLA imp 	ADC #   	ROR Acc 	---     	JMP ind 	ADC abs 	ROR abs 	BBR6 zp,rel
1byt, 6cyc	2byt, 6cyc(b)	2byt, 2cyc	1byt, 1cyc	2byt, 3cyc	2byt, 3cyc(b)	2byt, 5cyc	2byt, 5cyc	1byt, 4cyc	2byt, 2cyc(b)	1byt, 2cyc	1byt, 1cyc	3byt, 6cyc	3byt, 4cyc(b)	3byt, 6cyc	3byt, 5cyc
															
70 : BVS#	71 : ADC-	72 : ADC/	73 : NOP1	74 : STZZ	75 : ADCZ	76 : RORZ	77 : RMB7	78 : SEID	79 : ADCY	7A : PLYI	7B : NOP1	7C : JMPX	7D : ADCX	7E : RORX	7F : BBR7
BVS rel 	ADC (zp),Y	ADC (zp)	---     	STZ zp,X	ADC zp,X	ROR zp,X	RMB7 zp 	SEI imp 	ADC abs,Y	PLY imp 	---     	JMP abs,X	ADC abs,X	ROR abs,X	BBR7 zp,rel
2byt, 2cyc(ac)	2byt, 5cyc(ab)	2byt, 5cyc(b)	1byt, 1cyc	2byt, 4cyc	2byt, 4cyc(b)	2byt, 6cyc	2byt, 5cyc	1byt, 2cyc	3byt, 4cyc(ab)	1byt, 4cyc	1byt, 1cyc	3byt, 6cyc	3byt, 4cyc(ab)	3byt, 6cyc(a)	3byt, 5cyc
															
80 : BRAN	81 : STA+	82 : NOP2	83 : NOP1	84 : STY0	85 : STA0	86 : STX0	87 : SMB0	88 : DEYI	89 : BIT#	8A : TXAI	8B : NOP1	8C : STYA	8D : STAA	8E : STXA	8F : BBS0
BRA rel 	STA (zp,X)	---     	---     	STY zp  	STA zp  	STX zp  	SMB0 zp 	DEY imp 	BIT #   	TXA imp 	---     	STY abs 	STA abs 	STX abs 	BBS0 zp,rel
2byt, 3cyc(a)	2byt, 6cyc	2byt, 2cyc	1byt, 1cyc	2byt, 3cyc	2byt, 3cyc	2byt, 3cyc	2byt, 5cyc	1byt, 2cyc	2byt, 2cyc	1byt, 2cyc	1byt, 1cyc	3byt, 4cyc	3byt, 4cyc	3byt, 4cyc	3byt, 5cyc
															
90 : BCC#	91 : STA-	92 : STA/	93 : NOP1	94 : STYZ	95 : STAZ	96 : STXZ	97 : SMB1	98 : TYAI	99 : STAY	9A : TXSI	9B : NOP1	9C : STZA	9D : STAX	9E : STZX	9F : BBS1
BCC rel 	STA (zp),Y	STA (zp)	---     	STY zp,X	STA zp,X	STX zp,Y	SMB1 zp 	TYA imp 	STA abs,Y	TXS imp 	---     	STZ abs 	STA abs,X	STZ abs,X	BBS1 zp,rel
2byt, 2cyc(ac)	2byt, 6cyc	2byt, 5cyc	1byt, 1cyc	2byt, 4cyc	2byt, 4cyc	2byt, 4cyc	2byt, 5cyc	1byt, 2cyc	3byt, 5cyc	1byt, 2cyc	1byt, 1cyc	3byt, 4cyc	3byt, 5cyc	3byt, 5cyc	3byt, 5cyc
															
A0 : LDY#	A1 : LDA+	A2 : LDX#	A3 : NOP1	A4 : LDY0	A5 : LDA0	A6 : LDX0	A7 : SMB2	A8 : TAYI	A9 : LDA#	AA : TAXI	AB : NOP1	AC : LDYA	AD : LDAA	AE : LDXA	AF : BBS2
LDY #   	LDA (zp,X)	LDX #   	---     	LDY zp  	LDA zp  	LDX zp  	SMB2 zp 	TAY imp 	LDA #   	TAX imp 	---     	LDY abs 	LDA abs 	LDX abs 	BBS2 zp,rel
2byt, 2cyc	2byt, 6cyc	2byt, 2cyc	1byt, 1cyc	2byt, 3cyc	2byt, 3cyc	2byt, 3cyc	2byt, 5cyc	1byt, 2cyc	2byt, 2cyc	1byt, 2cyc	1byt, 1cyc	3byt, 4cyc	3byt, 4cyc	3byt, 4cyc	3byt, 5cyc
															
B0 : BCS#	B1 : LDA-	B2 : LDA/	B3 : NOP1	B4 : LDYZ	B5 : LDAZ	B6 : LDXZ	B7 : SMB3	B8 : CLVF	B9 : LDAY	BA : TSXI	BB : NOP1	BC : LDYX	BD : LDAX	BE : LDXY	BF : BBS3
BCS rel 	LDA (zp),Y	LDA (zp)	---     	LDY zp,X	LDA zp,X	LDX zp,Y	SMB3 zp 	CLV imp 	LDA abs,Y	TSX imp 	---     	LDY abs,X	LDA abs,X	LDX abs,Y	BBS3 zp,rel
2byt, 2cyc(ac)	2byt, 5cyc(a)	2byt, 5cyc	1byt, 1cyc	2byt, 4cyc	2byt, 4cyc	2byt, 4cyc	2byt, 5cyc	1byt, 2cyc	3byt, 4cyc(a)	1byt, 2cyc	1byt, 1cyc	3byt, 4cyc(a)	3byt, 4cyc(a)	3byt, 4cyc(a)	3byt, 5cyc
															
C0 : CPY#	C1 : CMP+	C2 : NOP2	C3 : NOP1	C4 : CPY0	C5 : CMP0	C6 : DEC0	C7 : SMB4	C8 : INYI	C9 : CMP#	CA : DEXI	CB : WAIT	CC : CPYA	CD : CMPA	CE : DECA	CF : BBS4
CPY #   	CMP (zp,X)	---     	---     	CPY zp  	CMP zp  	DEC zp  	SMB4 zp 	INY imp 	CMP #   	DEX imp 	WAI imp 	CPY abs 	CMP abs 	DEC abs 	BBS4 zp,rel
2byt, 2cyc	2byt, 6cyc	2byt, 2cyc	1byt, 1cyc	2byt, 3cyc	2byt, 3cyc	2byt, 5cyc	2byt, 5cyc	1byt, 2cyc	2byt, 2cyc	1byt, 2cyc	1byt, 3cyc	3byt, 4cyc	3byt, 4cyc	3byt, 6cyc	3byt, 5cyc
															
D0 : BNE#	D1 : CMP-	D2 : CMP/	D3 : NOP1	D4 : NOP2	D5 : CMPZ	D6 : DECZ	D7 : SMB5	D8 : CLDM	D9 : CMPY	DA : PHXI	DB : STOP	DC : NOP3	DD : CMPX	DE : DECX	DF : BBS5
BNE rel 	CMP (zp),Y	CMP (zp)	---     	---     	CMP zp,X	DEC zp,X	SMB5 zp 	CLD imp 	CMP abs,Y	PHX imp 	STP imp 	---     	CMP abs,X	DEC abs,X	BBS5 zp,rel
2byt, 2cyc(ac)	2byt, 5cyc(a)	2byt, 5cyc	1byt, 1cyc	2byt, 4cyc	2byt, 4cyc	2byt, 6cyc	2byt, 5cyc	1byt, 2cyc	3byt, 4cyc(a)	1byt, 3cyc	1byt, 3cyc	3byt, 4cyc	3byt, 4cyc(a)	3byt, 7cyc	3byt, 5cyc
															
E0 : CPX#	E1 : SBC+	E2 : NOP2	E3 : NOP1	E4 : CPX0	E5 : SBC0	E6 : INC0	E7 : SMB6	E8 : INXI	E9 : SBC#	EA : NOPE	EB : NOP1	EC : CPXA	ED : SBCA	EE : INCA	EF : BBS6
CPX #   	SBC (zp,X)	---     	---     	CPX zp  	SBC zp  	INC zp  	SMB6 zp 	INX imp 	SBC #   	NOP imp 	---     	CPX abs 	SBC abs 	INC abs 	BBS6 zp,rel
2byt, 2cyc	2byt, 6cyc(b)	2byt, 2cyc	1byt, 1cyc	2byt, 3cyc	2byt, 3cyc(b)	2byt, 5cyc	2byt, 5cyc	1byt, 2cyc	2byt, 2cyc(b)	1byt, 2cyc	1byt, 1cyc	3byt, 4cyc	3byt, 4cyc(b)	3byt, 6cyc	3byt, 5cyc
															
F0 : BEQ#	F1 : SBC-	F2 : SBC/	F3 : NOP1	F4 : NOP2	F5 : SBCZ	F6 : INCZ	F7 : SMB7	F8 : SEDM	F9 : SBCY	FA : PLXI	FB : NOP1	FC : NOP3	FD : SBCX	FE : INCX	FF : BBS7
BEQ rel 	SBC (zp),Y	SBC (zp)	---     	---     	SBC zp,X	INC zp,X	SMB7 zp 	SED imp 	SBC abs,Y	PLX imp 	---     	---     	SBC abs,X	INC abs,X	BBS7 zp,rel
2byt, 2cyc(ac)	2byt, 5cyc(ab)	2byt, 5cyc(b)	1byt, 1cyc	2byt, 4cyc	2byt, 4cyc(b)	2byt, 6cyc	2byt, 5cyc	1byt, 2cyc	3byt, 4cyc(ab)	1byt, 4cyc	1byt, 1cyc	3byt, 4cyc	3byt, 4cyc(ab)	3byt, 7cyc	3byt, 5cyc
															

-----------------------------------


Appendix B:  alphabetical list of 65c02 commands

This table lists all of the 65c02 commands in alphabetical order, including the addressing mode, opcode, 4-character code,
standard notation, # bytes, # cycles, and the flags affected by each command.  This table is tab-separated, so it can be loaded
into your favorite spreadsheet program.

There are 9 "pseudocommands" that allow branching to an address rather than relative branching; these commands do not exist on
the 65c02 but are included in the editor, which converts the branch to a relative address automatically.  In editor display mode 1
branches are shown as if they were these pseudocommands, but in editor display mode 2 they are shown as they are actually stored
in memory, as the standard relative branches.  These pseudocommands are shown with the addressing mode of {absolute}, with what 
would be the standard notation in curly braces {}, if these were real commands instead of stuff I made up.


cycle notes:	a: +1 if crossing page boundary
		b: +1 if D flag is set
		c: +1 if branch taken


ADC	add with carry					
						
	flag	effect				
	C	set if overflow in bit 7				
	Z	set if A = 0				
	V	set if sign bit is incorrect				
	N	set if bit 7 is set				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	Immediate 	$69	ADC#	ADC #   	2	2(b)
	Zero Page 	$65	ADC0	ADC zp  	2	3(b)
	Zero Page,X	$75	ADCZ	ADC zp,X	2	4(b)
	Absolute	$6D	ADCA	ADC abs 	3	4(b)
	Absolute,X	$7D	ADCX	ADC abs,X	3	4(ab)
	Absolute,Y	$79	ADCY	ADC abs,Y	3	4(ab)
	(Indirect,X)	$61	ADC+	ADC (zp,X)	2	6(b)
	(Indirect),Y	$71	ADC-	ADC (zp),Y	2	5(ab)
	(Indirect ZP)	$72	ADC/	ADC (zp)	2	5(b)
						
						
AND	logical AND					
						
	flag	effect				
	Z	set if A = 0				
	N	set if bit 7 is set				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	Immediate 	$29	AND#	AND #   	2	2
	Zero Page 	$25	AND0	AND zp  	2	3
	Zero Page,X	$35	ANDZ	AND zp,X	2	4
	Absolute	$2D	ANDA	AND abs 	3	4
	Absolute,X	$3D	ANDX	AND abs,X	3	4(a)
	Absolute,Y	$39	ANDY	AND abs,Y	3	4(a)
	(Indirect,X)	$21	AND+	AND (zp,X)	2	6
	(Indirect),Y	$31	AND-	AND (zp),Y	2	5(a)
	(Indirect ZP)	$32	AND/	AND (zp)	2	5
						
						
ASL	arithmetic shift left					
						
	flag	effect				
	C	set to contents of old bit 7				
	Z	set if A = 0				
	N	set if bit 7 is set				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	Accumulator	$0A	ASLI	ASL Acc 	1	2
	Zero Page 	$06	ASL0	ASL zp  	2	5
	Zero Page,X	$16	ASLZ	ASL zp,X	2	6
	Absolute	$0E	ASLA	ASL abs 	3	6
	Absolute,X	$1E	ASLX	ASL abs,X	3	6(a)
						
						
BBR	branch on bit reset					
						
	flag	effect				
	none	none				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	ZP, relative	$0F	BBR0	BBR0 zp,rel	3	5
	ZP, relative	$1F	BBR1	BBR1 zp,rel	3	5
	ZP, relative	$2F	BBR2	BBR2 zp,rel	3	5
	ZP, relative	$3F	BBR3	BBR3 zp,rel	3	5
	ZP, relative	$4F	BBR4	BBR4 zp,rel	3	5
	ZP, relative	$5F	BBR5	BBR5 zp,rel	3	5
	ZP, relative	$6F	BBR6	BBR6 zp,rel	3	5
	ZP, relative	$7F	BBR7	BBR7 zp,rel	3	5
						
						
BBS	branch on bit set					
						
	flag	effect				
	none	none				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	ZP, relative	$8F	BBS0	BBS0 zp,rel	3	5
	ZP, relative	$9F	BBS1	BBS1 zp,rel	3	5
	ZP, relative	$AF	BBS2	BBS2 zp,rel	3	5
	ZP, relative	$BF	BBS3	BBS3 zp,rel	3	5
	ZP, relative	$CF	BBS4	BBS4 zp,rel	3	5
	ZP, relative	$DF	BBS5	BBS5 zp,rel	3	5
	ZP, relative	$EF	BBS6	BBS6 zp,rel	3	5
	ZP, relative	$FF	BBS7	BBS7 zp,rel	3	5
						
						
BCC	branch if carry clear					
						
	flag	effect				
	none	none				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	relative	$90	BCC#	BCC rel 	2	2(ac)
	{absolute}	{$90}	BCCA	{BCC abs}	2	2(ac)
						
						
BCS	branch if carry set					
						
	flag	effect				
	none	none				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	relative	$B0	BCS#	BCS rel 	2	2(ac)
	{absolute}	{$B0}	BCSA	{BCS abs}	2	2(ac)	
					
						
BEQ	branch if equal					
						
	flag	effect				
	none	none				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	relative	$F0	BEQ#	BEQ rel 	2	2(ac)
	{absolute}	{$F0}	BEQA	{BEQ abs}	2	2(ac)
						
						
BIT	bit test					
						
	flag	effect				
	Z	set if the result of the AND is zero				
	V	set to bit 6 of the memory value				
	N	set to bit 7 of the memory value				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	Immediate 	$89	BIT#	BIT #   	2	2
	Zero Page 	$24	BIT0	BIT zp  	2	3
	Zero Page,X	$34	BITZ	BIT zp,X	2	4
	Absolute	$2C	BITA	BIT abs 	3	4
	Absolute,X	$3C	BITX	BIT abs,X	3	4(a)
						
						
BMI	branch if minus					
						
	flag	effect				
	none	none				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	relative	$30	BMI#	BMI rel 	2	2(ac)
	{absolute}	{$30}	BMIA	{BMI abs}	2	2(ac)
						
						
BNE	branch if not equal					
						
	flag	effect				
	none	none				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	relative	$D0	BNE#	BNE rel 	2	2(ac)
	{absolute}	{$D0}	BNEA	{BNE abs}	2	2(ac)
						
						
BPL	branch if positive					
						
	flag	effect				
	none	none				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	relative	$10	BPL#	BPL rel 	2	2(ac)
	{absolute}	{$10}	BPLA	{BPL abs}	2	2(ac)
						
						
BRA	branch always					
						
	flag	effect				
	none	none				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	relative	$80	BRAN	BRA rel 	2	3(a)
	{absolute}	{$80}	BRAA	{BRA abs}	2	2(ac)
						
						
BRK	force interrupt					
						
	flag	effect				
	B	set to 1				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	implied 	$00	BRK0	BRK imp 	1	7
						
						
BVC	branch if overflow clear					
						
	flag	effect				
	none	none				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	relative	$50	BVC#	BVC rel 	2	2(ac)
	{absolute}	{$50}	BVCA	{BVC abs}	2	2(ac)	
					
						
BVS	branch if overflow set					
						
	flag	effect				
	none	none				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	relative	$70	BVS#	BVS rel 	2	2(ac)
	{absolute}	{$70}	BVSA	{BVS abs}	2	2(ac)
						
						
CLC	clear carry flag					
						
	flag	effect				
	C	set to 0				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	implied 	$18	CLCF	CLC imp 	1	2
						
						
CLD	clear decimal mode flag					
						
	flag	effect				
	D	set to 0				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	implied 	$D8	CLDM	CLD imp 	1	2
						
						
CLI	clear interrupt disable					
						
	flag	effect				
	I	set to 0				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	implied 	$58	CLID	CLI imp 	1	2
						
						
CLV	clear overflow flag					
						
	flag	effect				
	V	set to 0				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	implied 	$B8	CLVF	CLV imp 	1	2


CMP	compare accumulator					
						
	flag	effect				
	C	set if A>=M				
	Z	set if A=M				
	N	set if bit 7 of the result is set				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	Immediate 	$C9	CMP#	CMP #   	2	2
	Zero Page 	$C5	CMP0	CMP zp  	2	3
	Zero Page,X	$D5	CMPZ	CMP zp,X	2	4
	Absolute	$CD	CMPA	CMP abs 	3	4
	Absolute,X	$DD	CMPX	CMP abs,X	3	4(a)
	Absolute,Y	$D9	CMPY	CMP abs,Y	3	4(a)
	(Indirect,X)	$C1	CMP+	CMP (zp,X)	2	6
	(Indirect),Y	$D1	CMP-	CMP (zp),Y	2	5(a)
	(Indirect ZP)	$D2	CMP/	CMP (zp)	2	5
						
						
CPX	compare X register					
						
	flag	effect				
	C	set if X>=M				
	Z	set if X=M				
	N	set if bit 7 of the result is set				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	Immediate 	$E0	CPX#	CPX #   	2	2
	Zero Page 	$E4	CPX0	CPX zp  	2	3
	Absolute	$EC	CPXA	CPX abs 	3	4
						
						
CPY	compare Y register					
						
	flag	effect				
	C	set if Y>=M				
	Z	set if Y=M				
	N	set if bit 7 of the result is set				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	Immediate 	$C0	CPY#	CPY #   	2	2
	Zero Page 	$C4	CPY0	CPY zp  	2	3
	Absolute	$CC	CPYA	CPY abs 	3	4
						
						
DEC	decrement memory					
						
	flag	effect				
	Z	set if result is zero				
	N	set if bit 7 of the result is set				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	Accumulator	$3A	DECI	DEC Acc 	1	2
	Zero Page 	$C6	DEC0	DEC zp  	2	5
	Zero Page,X	$D6	DECZ	DEC zp,X	2	6
	Absolute	$CE	DECA	DEC abs 	3	6
	Absolute,X	$DE	DECX	DEC abs,X	3	7
						
						
DEX	decrement X register					
						
	flag	effect				
	Z	set if X is zero				
	N	set if bit 7 of X is set				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	Implied 	$CA	DEXI	DEX imp 	1	2
						
						
DEY	decrement Y register					
						
	flag	effect				
	Z	set if Y is zero				
	N	set if bit 7 of Y is set				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	Implied 	$88	DEYI	DEY imp 	1	2
						
						
EOR	exclusive OR					
						
	flag	effect				
	Z	set if A is zero				
	N	set if bit 7 is set				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	Immediate 	$49	EOR#	EOR #   	2	2
	Zero Page 	$45	EOR0	EOR zp  	2	3
	Zero Page,X	$55	EORZ	EOR zp,X	2	4
	Absolute	$4D	EORA	EOR abs 	3	4
	Absolute,X	$5D	EORX	EOR abs,X	3	4(a)
	Absolute,Y	$59	EORY	EOR abs,Y	3	4(a)
	(Indirect,X)	$41	EOR+	EOR (zp,X)	2	6
	(Indirect),Y	$51	EOR-	EOR (zp),Y	2	5(a)
	(Indirect ZP)	$52	EOR/	EOR (zp)	2	5
						
						
INC	increment memory					
						
	flag	effect				
	Z	set if result is zero				
	N	set if bit 7 of the result is set				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	Accumulator	$1A	INCI	INC Acc 	1	2
	Zero Page 	$E6	INC0	INC zp  	2	5
	Zero Page,X	$F6	INCZ	INC zp,X	2	6
	Absolute	$EE	INCA	INC abs 	3	6
	Absolute,X	$FE	INCX	INC abs,X	3	7
						
						
INX	increment X register					
						
	flag	effect				
	Z	set if X is zero				
	N	set if bit 7 of X is set				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	Implied 	$E8	INXI	INX imp 	1	2
						
						
INY	increment Y register					
						
	flag	effect				
	Z	set if Y is zero				
	N	set if bit 7 of Y is set				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	Implied 	$C8	INYI	INY imp 	1	2
						
						
JMP	jump					
						
	flag	effect				
	none	none				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	Absolute	$4C	JMPA	JMP abs 	3	3
	Indirect	$6C	JMPI	JMP ind 	3	6
	Absolute,X	$7C	JMPX	JMP abs,X	3	6
						
						
JSR	jump to subroutine					
						
	flag	effect				
	none	none				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	Absolute	$20	JSRA	JSR abs 	3	6
						
						
LDA	load accumulator					
						
	flag	effect				
	Z	set if A is zero				
	N	set if bit 7 of A is set				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	Immediate 	$A9	LDA#	LDA #   	2	2
	Zero Page 	$A5	LDA0	LDA zp  	2	3
	Zero Page,X	$B5	LDAZ	LDA zp,X	2	4
	Absolute	$AD	LDAA	LDA abs 	3	4
	Absolute,X	$BD	LDAX	LDA abs,X	3	4(a)
	Absolute,Y	$B9	LDAY	LDA abs,Y	3	4(a)
	(Indirect,X)	$A1	LDA+	LDA (zp,X)	2	6
	(Indirect),Y	$B1	LDA-	LDA (zp),Y	2	5(a)
	(Indirect ZP)	$B2	LDA/	LDA (zp)	2	5
						
						
LDX	load X register					
						
	flag	effect				
	Z	set if X is zero				
	N	set if bit 7 of X is set				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	Immediate 	$A2	LDX#	LDX #   	2	2
	Zero Page 	$A6	LDX0	LDX zp  	2	3
	Zero Page,Y	$B6	LDXZ	LDX zp,Y	2	4
	Absolute	$AE	LDXA	LDX abs 	3	4
	Absolute,Y	$BE	LDXY	LDX abs,Y	3	4(a)
						
						
LDY	load Y register					
						
	flag	effect				
	Z	set if Y is zero				
	N	set if bit 7 of Y is set				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	Immediate 	$A0	LDY#	LDY #   	2	2
	Zero Page 	$A4	LDY0	LDY zp  	2	3
	Zero Page,X	$B4	LDYZ	LDY zp,X	2	4
	Absolute	$AC	LDYA	LDY abs 	3	4
	Absolute,X	$BC	LDYX	LDY abs,X	3	4(a)
						
						
LSR	logical shift right					
						
	flag	effect				
	C	set to contents of old bit 0				
	Z	set if result is zero				
	N	set if bit 7 of the result is set				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	Accumulator	$4A	LSRI	LSR Acc 	1	2
	Zero Page 	$46	LSR0	LSR zp  	2	5
	Zero Page,X	$56	LSRZ	LSR zp,X	2	6
	Absolute	$4E	LSRA	LSR abs 	3	6
	Absolute,X	$5E	LSRX	LSR abs,X	3	6(a)
						
						
NOP	no operation					
						
	flag	effect				
	none	none				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	Implied 	$EA	NOPE	NOP imp 	1	2
						
						
ORA	logical inclusive OR					
						
	flag	effect				
	Z	set if A is zero				
	N	set if bit 7 is set				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	Immediate 	$09	ORA#	ORA #   	2	2
	Zero Page 	$05	ORA0	ORA zp  	2	3
	Zero Page,X	$15	ORAZ	ORA zp,X	2	4
	Absolute	$0D	ORAA	ORA abs 	3	4
	Absolute,X	$1D	ORAX	ORA abs,X	3	4(a)
	Absolute,Y	$19	ORAY	ORA abs,Y	3	4(a)
	(Indirect,X)	$01	ORA+	ORA (zp,X)	2	2
	(Indirect),Y	$11	ORA-	ORA (zp),Y	2	5(a)
	(Indirect ZP)	$12	ORA/	ORA (zp)	2	5


PHA	push accumulator					
						
	flag	effect				
	none	none				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	Implied 	$48	PHAI	PHA imp 	1	3
						
						
PHP	push processor status					
						
	flag	effect				
	none	none				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	Implied 	$08	PHPI	PHP imp 	1	3
						
						
PHX	push X register					
						
	flag	effect				
	none	none				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	Implied 	$DA	PHXI	PHX imp 	1	3
						
						
PHY	push Y register					
						
	flag	effect				
	none	none				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	Implied 	$5A	PHYI	PHY imp 	1	3
						
						
PLA	pull accumulator					
						
	flag	effect				
	Z	set if A=0				
	N	set if bit 7 of A is set				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	Implied 	$68	PLAI	PLA imp 	1	4
						
						
PLP	pull processor status					
						
	flag	effect				
	C	set from stack				
	Z	set from stack				
	I	set from stack				
	D	set from stack				
	B	set from stack				
	V	set from stack				
	N	set from stack				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	Implied 	$28	PLPI	PLP imp 	1	4
						
						
PLX	pull X register					
						
	flag	effect				
	Z	set if X=0				
	N	set if bit 7 of X is set				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	Implied 	$FA	PLXI	PLX imp 	1	4
						
						
PLY	pull Y register					
						
	flag	effect				
	Z	set if Y=0				
	N	set if bit 7 of Y is set				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	Implied 	$7A	PLYI	PLY imp 	1	4
						
						
RMB	reset memory bit					
						
	flag	effect				
	none	none				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	Zero Page	$07	RMB0	RMB0 zp 	2	5
	Zero Page	$17	RMB1	RMB1 zp 	2	5
	Zero Page	$27	RMB2	RMB2 zp 	2	5
	Zero Page	$37	RMB3	RMB3 zp 	2	5
	Zero Page	$47	RMB4	RMB4 zp 	2	5
	Zero Page	$57	RMB5	RMB5 zp 	2	5
	Zero Page	$67	RMB6	RMB6 zp 	2	5
	Zero Page	$77	RMB7	RMB7 zp 	2	5
						
						
ROL	rotate left					
						
	flag	effect				
	C	set to contents of old bit 7				
	Z	set if A=0				
	N	set if bit 7 of the result is set				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	Accumulator	$2A	ROLI	ROL Acc 	1	2
	Zero Page 	$26	ROL0	ROL zp  	2	5
	Zero Page,X	$36	ROLZ	ROL zp,X	2	6
	Absolute	$2E	ROLA	ROL abs 	3	6
	Absolute,X	$3E	ROLX	ROL abs,X	3	6(a)
						
						
ROR	rotate right					
						
	flag	effect				
	C	set to contents of old bit 0				
	Z	set if A=0				
	N	set if bit 7 of the result is set				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	Accumulator	$6A	RORI	ROR Acc 	1	2
	Zero Page 	$66	ROR0	ROR zp  	2	5
	Zero Page,X	$76	RORZ	ROR zp,X	2	6
	Absolute	$6E	RORA	ROR abs 	3	6
	Absolute,X	$7E	RORX	ROR abs,X	3	6(a)
						
						
RTI	return from interrupt					
						
	flag	effect				
	C	set from stack				
	Z	set from stack				
	I	set from stack				
	D	set from stack				
	B	set from stack				
	V	set from stack				
	N	set from stack				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	Implied 	$40	RTII	RTI imp 	1	6
						
						
RTS	return from subroutine					
						
	flag	effect				
	none	none				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	Implied 	$60	RTSI	RTS imp 	1	6
						
						
SBC	subtract with carry					
						
	flag	effect				
	C	set if overflow in bit 7				
	Z	set if A = 0				
	V	set if sign bit is incorrect				
	N	set if bit 7 is set				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	Immediate 	$E9	SBC#	SBC #   	2	2(b)
	Zero Page 	$E5	SBC0	SBC zp  	2	3(b)
	Zero Page,X	$F5	SBCZ	SBC zp,X	2	4(b)
	Absolute	$ED	SBCA	SBC abs 	3	4(b)
	Absolute,X	$FD	SBCX	SBC abs,X	3	4(ab)
	Absolute,Y	$F9	SBCY	SBC abs,Y	3	4(ab)
	(Indirect,X)	$E1	SBC+	SBC (zp,X)	2	6(b)
	(Indirect),Y	$F1	SBC-	SBC (zp),Y	2	5(ab)
	(Indirect ZP)	$F2	SBC/	SBC (zp)	2	5(b)
						
						
SEC	set carry flag					
						
	flag	effect				
	C	set to 1				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	Implied 	$38	SECF	SEC imp 	1	2
						
						
SED	set decimal mode flag					
						
	flag	effect				
	D	set to 1				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	Implied 	$F8	SEDM	SED imp 	1	2
						
						
SEI	set interrupt disable					
						
	flag	effect				
	I	set to 1				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	Implied 	$78	SEID	SEI imp 	1	2
						
						
SMB	set memory bit					
						
	flag	effect				
	none	none				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	Zero Page	$87	SMB0	SMB0 zp 	2	5
	Zero Page	$97	SMB1	SMB1 zp 	2	5
	Zero Page	$A7	SMB2	SMB2 zp 	2	5
	Zero Page	$B7	SMB3	SMB3 zp 	2	5
	Zero Page	$C7	SMB4	SMB4 zp 	2	5
	Zero Page	$D7	SMB5	SMB5 zp 	2	5
	Zero Page	$E7	SMB6	SMB6 zp 	2	5
	Zero Page	$F7	SMB7	SMB7 zp 	2	5
						
						
STA	store accumulator					
						
	flag	effect				
	none	none				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	Zero Page 	$85	STA0	STA zp  	2	3
	Zero Page,X	$95	STAZ	STA zp,X	2	4
	Absolute	$8D	STAA	STA abs 	3	4
	Absolute,X	$9D	STAX	STA abs,X	3	5
	Absolute,Y	$99	STAY	STA abs,Y	3	5
	(Indirect,X)	$81	STA+	STA (zp,X)	2	6
	(Indirect),Y	$91	STA-	STA (zp),Y	2	6
	(Indirect ZP)	$92	STA/	STA (zp)	2	5
						
						
STP	stop					
						
	flag	effect				
	none	none				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	Implied 	$DB	STOP	STP imp 	1	3
						
						
STX	store X register					
						
	flag	effect				
	none	none				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	Zero Page 	$86	STX0	STX zp  	2	3
	Zero Page,Y	$96	STXZ	STX zp,Y	2	4
	Absolute	$8E	STXA	STX abs 	3	4
						
						
STY	store Y register					
						
	flag	effect				
	none	none				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	Zero Page 	$84	STY0	STY zp  	2	3
	Zero Page,X	$94	STYZ	STY zp,X	2	4
	Absolute	$8C	STYA	STY abs 	3	4
						
						
STZ	Store zero in memory					
						
	flag	effect				
	none	none				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	Zero Page 	$64	STZ0	STZ zp  	2	3
	Zero Page,X	$74	STZZ	STZ zp,X	2	4
	Absolute	$9C	STZA	STZ abs 	3	4
	Absolute,X	$9E	STZX	STZ abs,X	3	5
						
						
TAX	transfer accumulator to X					
						
	flag	effect				
	Z	set if X=0				
	N	set if bit 7 of X is set				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	Implied 	$AA	TAXI	TAX imp 	1	2
						
						
TAY	transfer accumulator to Y					
						
	flag	effect				
	Z	set if Y=0				
	N	set if bit 7 of Y is set				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	Implied 	$A8	TAYI	TAY imp 	1	2
						
						
TRB	test and reset bits					
						
	flag	effect				
	Z	set if the memory value held any of the specified bits				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	Zero Page 	$14	TRB0	TRB zp  	2	5
	Absolute	$1C	TRBA	TRB abs 	3	6
						
						
TSB	test and set bits					
						
	flag	effect				
	Z	set if the memory value held any of the specified bits				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	Zero Page 	$04	TSB0	TSB zp  	2	5
	Absolute	$0C	TSBA	TSB abs 	3	6
						
						
TSX	transfer stack pointer to X					
						
	flag	effect				
	Z	set if X=0				
	N	set if bit 7 of X is set				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	Implied 	$BA	TSXI	TSX imp 	1	2
						
						
TXA	transfer X to accumulator					
						
	flag	effect				
	Z	set if A=0				
	N	set if bit 7 of A is set				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	Implied 	$8A	TXAI	TXA imp 	1	2
						
						
TXS	transfer X to stack pointer					
						
	flag	effect				
	none	none				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	Implied 	$9A	TXSI	TXS imp 	1	2
						
						
TYA	transfer Y to accumulator					
						
	flag	effect				
	Z	set if A=0				
	N	set if bit 7 of A is set				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	Implied 	$98	TYAI	TYA imp 	1	2
						
						
WAI	wait for interrupt					
						
	flag	effect				
	B	set to 1				
						
	addressing mode	opcode	4char	standard	#bytes	#cycles
						
	Implied 	$CB	WAIT	WAI imp 	1	3

-30-